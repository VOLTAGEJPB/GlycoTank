﻿(function(){
  'use strict';
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const todayStr = () => new Date().toISOString().slice(0,10);
  const clamp = (v,min,max)=> Math.max(min, Math.min(max, v));
  function load(){ try { return JSON.parse(localStorage.getItem('glycotank')||'{}'); } catch(e){ return {}; } }
  function save(state){ localStorage.setItem('glycotank', JSON.stringify(state)); }
  function uid(){ return Math.random().toString(36).slice(2,10); }
  const defaults = {
    workouts:[], meals:[], checks:[],
    settings: { proteinTarget:140, fiberTarget:28, carbGuide:250, glycoCap:400, uptakePct:85, setCost:6.0, cardioGpmIntensity1:0.33 }
  };
  const state = Object.assign({}, defaults, load());
  state.settings = Object.assign({}, defaults.settings, state.settings||{});
  if('serviceWorker' in navigator){ window.addEventListener('load', ()=> navigator.serviceWorker.register('./service-worker.js')); }
  let deferredPrompt;
  window.addEventListener('beforeinstallprompt', (e)=>{ e.preventDefault(); deferredPrompt=e; const btn=$('#installBtn'); if(btn){ btn.hidden=false; btn.onclick=async()=>{ btn.disabled=true; await deferredPrompt.prompt(); deferredPrompt=null; }; }});
  $$('#nav button').forEach(btn=>{ btn.addEventListener('click', ()=>{ $$('#nav button').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); const tab=btn.dataset.tab; $$('.tab').forEach(sec=>sec.hidden=true); $('#tab-'+tab).hidden=false; if(tab==='dash') renderDashboard(); if(tab==='history') renderHistory(); if(tab==='settings') renderSettings(); });});
  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  function dictateTo(inputEl){ if(!SpeechRec){ alert('Speech recognition not supported in this browser.'); return; } const r=new SpeechRec(); r.lang='en-US'; r.interimResults=false; r.maxAlternatives=1; r.onresult = e => { inputEl.value = e.results[0][0].transcript; }; r.start(); }
  const wType=$('#wType'), strengthFields=$('#strengthFields'), cardioFields=$('#cardioFields');
  wType.addEventListener('change', ()=>{ const v=wType.value; strengthFields.hidden = v!=='strength'; cardioFields.hidden = v!=='cardio'; });
  $('#wDate').value = todayStr();
  $('#voiceWorkout').addEventListener('click', e=>{ e.preventDefault(); dictateTo($('#wName')); });
  $('#saveWorkout').addEventListener('click', ()=>{ const date=$('#wDate').value||todayStr(); const type=wType.value; const notes=$('#wNotes').value.trim(); let entry;
    if(type==='strength'){ const name=$('#wName').value.trim()||'Strength'; const sets=parseInt($('#wSets').value||'0',10); const reps=parseInt($('#wReps').value||'0',10); const weight=parseFloat($('#wWeight').value||'0'); entry={ id:uid(), date, type, name, sets, reps, weight, notes }; }
    else { const name=$('#wCardioName').value.trim()||'Cardio'; const mins=parseInt($('#wMins').value||'0',10); const intensity=parseInt($('#wIntensity').value||'3',10); entry={ id:uid(), date, type, name, mins, intensity, notes }; }
    state.workouts.push(entry); save(state); clearWorkoutForm(); renderDashboard(); alert('Workout saved.');
  });
  function clearWorkoutForm(){ $('#wName').value=''; $('#wSets').value=3; $('#wReps').value=5; $('#wWeight').value=100; $('#wCardioName').value=''; $('#wMins').value=30; $('#wIntensity').value=3; $('#wNotes').value=''; $('#wDate').value=todayStr(); }
  $('#mDate').value = todayStr();
  $('#voiceMeal').addEventListener('click', e=>{ e.preventDefault(); dictateTo($('#mName')); });
  $('#saveMeal').addEventListener('click', ()=>{ const date=$('#mDate').value||todayStr(); const name=$('#mName').value.trim()||'Meal'; const kcal=num($('#mCalories').value); const carbs=num($('#mCarbs').value); const protein=num($('#mProtein').value); const fat=num($('#mFat').value); const fiber=num($('#mFiber').value); const notes=$('#mNotes').value.trim(); const entry={ id:uid(), date, name, kcal, carbs, protein, fat, fiber, notes }; state.meals.push(entry); save(state); clearMealForm(); renderDashboard(); alert('Meal saved.'); });
  function clearMealForm(){ $('#mDate').value=todayStr(); $('#mName').value=''; $('#mCalories').value=''; $('#mCarbs').value=''; $('#mProtein').value=''; $('#mFat').value=''; $('#mFiber').value=''; $('#mNotes').value=''; }
  $('#cDate').value = todayStr();
  $('#saveCheckin').addEventListener('click', ()=>{ const date=$('#cDate').value||todayStr(); const mood=$('#cMood').value; const sleep=parseFloat($('#cSleep').value||'0'); const rhr=parseInt($('#cRHR').value||'0',10); const notes=$('#cNotes').value.trim(); const entry={ id:uid(), date, mood, sleep, rhr, notes }; state.checks.push(entry); save(state); alert('Check-in saved.'); });
  function computeGlycoForDay(dateStr){ const cfg=state.settings; const yesterday=new Date(dateStr); yesterday.setDate(yesterday.getDate()-1); const y=yesterday.toISOString().slice(0,10); let start=(state.glycoHistory && state.glycoHistory[y]!=null)?state.glycoHistory[y]:(cfg.glycoCap*0.7);
    const meals=state.meals.filter(m=>m.date===dateStr); const added=meals.reduce((sum,m)=> sum+(num(m.carbs)*(cfg.uptakePct/100)), 0);
    const wos=state.workouts.filter(w=>w.date===dateStr); let cost=0; for(const w of wos){ if(w.type==='strength'){ cost += (num(w.sets)||0)*cfg.setCost; } else if(w.type==='cardio'){ const mins=num(w.mins)||0; const intensity=clamp(num(w.intensity)||1,1,5); cost += mins*cfg.cardioGpmIntensity1*intensity; } else { cost += 10; } }
    let end = clamp(start + added - cost, 0, cfg.glycoCap); return { start, added, cost, end };
  }
  function rebuildGlycoHistory(days=14){ state.glycoHistory = state.glycoHistory || {}; const now=new Date(); const startDate=new Date(now); startDate.setDate(startDate.getDate()-(days-1)); let prev=state.settings.glycoCap*0.7; for(let i=0;i<days;i++){ const d=new Date(startDate); d.setDate(startDate.getDate()+i); const ds=d.toISOString().slice(0,10); state.glycoHistory[ds]=prev; const {end}=computeGlycoForDay(ds); state.glycoHistory[ds]=end; prev=end; } }
  function num(v){ const n=parseFloat(v); return isNaN(n)?0:n; }
  function renderDashboard(){ rebuildGlycoHistory(14); const ds=todayStr(); const meals=state.meals.filter(m=>m.date===ds); const wos=state.workouts.filter(w=>w.date===ds); const kcal=meals.reduce((s,m)=> s+num(m.kcal),0); const protein=meals.reduce((s,m)=> s+num(m.protein),0); const fiber=meals.reduce((s,m)=> s+num(m.fiber),0);
    $('#kcalToday').textContent=Math.round(kcal); $('#proteinToday').textContent=Math.round(protein); $('#fiberToday').textContent=Math.round(fiber);
    const pPct=clamp(protein/state.settings.proteinTarget*100,0,100); const fPct=clamp(fiber/state.settings.fiberTarget*100,0,100); $('#proteinProgress').value=pPct; $('#fiberProgress').value=fPct;
    const gly=state.glycoHistory[ds]||0; $('#glycoNow').textContent=`${Math.round(gly)} g`; const pct=clamp(gly/state.settings.glycoCap*100,0,100); const bar=$('#glycoBar'); bar.value=pct; const wrap=$('#glycoBarWrap'); wrap.classList.remove('ok','warn','danger'); wrap.classList.add(pct<25?'danger':pct<50?'warn':'ok'); $('#glycoHint').textContent = pct<25?'Low — consider carbs/rest': pct<50?'Moderate — easy day':'Good — ready to train';
    $('#todayWorkouts').innerHTML = wos.length ? wos.map(renderWorkoutItem).join('') : '<span class="muted">No workouts yet.</span>';
    $('#todayMeals').innerHTML = meals.length ? meals.map(renderMealItem).join('') : '<span class="muted">No meals yet.</span>';
    drawGlycoChart();
  }
  function renderWorkoutItem(w){ if(w.type==='strength'){ return `<div><strong>${w.name}</strong> — ${w.sets}×${w.reps} @ ${w.weight}kg</div>`; } else if(w.type==='cardio'){ return `<div><strong>${w.name}</strong> — ${w.mins} min (intensity ${w.intensity})</div>`; } else { return `<div><strong>${w.name||w.type}</strong></div>`; } }
  function renderMealItem(m){ return `<div><strong>${m.name}</strong> — ${Math.round(num(m.kcal))} kcal • C${num(m.carbs)} P${num(m.protein)} F${num(m.fat)} Fib${num(m.fiber)}</div>`; }
  $('#quickAddWorkout').addEventListener('click', e=>{ e.preventDefault(); $('#nav [data-tab="workout"]').click(); });
  $('#quickAddMeal').addEventListener('click', e=>{ e.preventDefault(); $('#nav [data-tab="meal"]').click(); });
  function renderHistory(){ const groups={}; for(const m of state.meals){ groups[m.date]=groups[m.date]||{meals:[],workouts:[]}; groups[m.date].meals.push(m); } for(const w of state.workouts){ groups[w.date]=groups[w.date]||{meals:[],workouts:[]}; groups[w.date].workouts.push(w); }
    const dates=Object.keys(groups).sort().reverse(); const el=$('#history'); if(!dates.length){ el.innerHTML='<span class="muted">Nothing yet.</span>'; return; }
    el.innerHTML = dates.map(d=>{ const ms=groups[d].meals.map(renderMealItem).join(''); const ws=groups[d].workouts.map(renderWorkoutItem).join(''); return `<div class="group"><h4>${d}</h4>${ws||'<div class="muted">No workouts.</div>'}${ms||'<div class="muted">No meals.</div>'}</div>`; }).join('');
  }
  function download(filename, text){ const blob=new Blob([text],{type:'text/plain'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=filename; a.click(); URL.revokeObjectURL(url); }
  $('#exportJson').addEventListener('click', ()=>{ download('glycotank-export.json', JSON.stringify(state,null,2)); });
  $('#exportCSV').addEventListener('click', ()=>{ const wcsv=['id,date,type,name,sets,reps,weight,mins,intensity,notes']; for(const w of state.workouts){ wcsv.push([w.id,w.date,w.type,quote(w.name),w.sets||'',w.reps||'',w.weight||'',w.mins||'',w.intensity||'',quote(w.notes||'')].join(',')); }
    const mcsv=['id,date,name,kcal,carbs,protein,fat,fiber,notes']; for(const m of state.meals){ mcsv.push([m.id,m.date,quote(m.name),m.kcal||'',m.carbs||'',m.protein||'',m.fat||'',m.fiber||'',quote(m.notes||'')].join(',')); }
    download('workouts.csv', wcsv.join('\n')); download('meals.csv', mcsv.join('\n'));
  });
  function quote(s){ if(s==null) return ''; const t=String(s); if(t.includes(',')||t.includes('"')||t.includes('\n')){ return '"' + t.replace(/"/g,'""') + '"'; } return t; }
  $('#clearAll').addEventListener('click', ()=>{ if(confirm('This will delete all local data. Proceed?')){ localStorage.removeItem('glycotank'); Object.assign(state, JSON.parse(JSON.stringify(defaults))); renderDashboard(); renderHistory(); renderSettings(); alert('Cleared.'); }});
  function renderSettings(){ $('#sProtein').value=state.settings.proteinTarget; $('#sFiber').value=state.settings.fiberTarget; $('#sCarb').value=state.settings.carbGuide; $('#sGlycoCap').value=state.settings.glycoCap; $('#sUptake').value=state.settings.uptakePct; $('#sSetCost').value=state.settings.setCost; $('#sCardioGpm').value=state.settings.cardioGpmIntensity1; }
  $('#saveSettings').addEventListener('click', ()=>{ state.settings.proteinTarget=num($('#sProtein').value)||defaults.settings.proteinTarget; state.settings.fiberTarget=num($('#sFiber').value)||defaults.settings.fiberTarget; state.settings.carbGuide=num($('#sCarb').value)||defaults.settings.carbGuide; state.settings.glycoCap=num($('#sGlycoCap').value)||defaults.settings.glycoCap; state.settings.uptakePct=clamp(num($('#sUptake').value)||defaults.settings.uptakePct,10,100); state.settings.setCost=num($('#sSetCost').value)||defaults.settings.setCost; state.settings.cardioGpmIntensity1=num($('#sCardioGpm').value)||defaults.settings.cardioGpmIntensity1; save(state); renderDashboard(); alert('Settings saved.'); });
  $('#resetSettings').addEventListener('click', ()=>{ state.settings = JSON.parse(JSON.stringify(defaults.settings)); save(state); renderSettings(); renderDashboard(); });
  function drawGlycoChart(){ const c=$('#glycoChart'); const ctx=c.getContext('2d'); const w=c.width=c.clientWidth*devicePixelRatio; const h=c.height=160*devicePixelRatio; ctx.clearRect(0,0,w,h); const days=14; const labels=[]; const values=[]; const cap=state.settings.glycoCap; const now=new Date(); for(let i=days-1;i>=0;i--){ const d=new Date(now); d.setDate(now.getDate()-i); const ds=d.toISOString().slice(0,10); labels.push(ds.slice(5)); values.push(state.glycoHistory && state.glycoHistory[ds]!=null ? state.glycoHistory[ds] : cap*0.7); }
    const padding=12*devicePixelRatio; const gx0=padding, gx1=w-padding, gy0=padding, gy1=h-padding; const x=i=> gx0+(gx1-gx0)*i/(days-1); const y=v=> gy1-(gy1-gy0)*(v/cap);
    ctx.globalAlpha=0.25; ctx.strokeStyle='#3a3f55'; ctx.lineWidth=1*devicePixelRatio; for(const frac of [0.25,0.5,0.75,1.0]){ const gy=y(cap*frac); ctx.beginPath(); ctx.moveTo(gx0,gy); ctx.lineTo(gx1,gy); ctx.stroke(); } ctx.globalAlpha=1;
    ctx.beginPath(); for(let i=0;i<values.length;i++){ const xv=x(i), yv=y(values[i]); if(i===0) ctx.moveTo(xv,yv); else ctx.lineTo(xv,yv); } ctx.strokeStyle='#57cc99'; ctx.lineWidth=2.5*devicePixelRatio; ctx.stroke();
    const grad=ctx.createLinearGradient(0,gy0,0,gy1); grad.addColorStop(0,'rgba(87,204,153,0.25)'); grad.addColorStop(1,'rgba(87,204,153,0.02)'); ctx.lineTo(gx1,gy1); ctx.lineTo(gx0,gy1); ctx.closePath(); ctx.fillStyle=grad; ctx.fill();
  }
  $('#tab-dash').hidden=false; $('#tab-workout').hidden=true; $('#tab-meal').hidden=true; $('#tab-checkin').hidden=true; $('#tab-history').hidden=true; $('#tab-settings').hidden=true;
  renderDashboard();
})();

