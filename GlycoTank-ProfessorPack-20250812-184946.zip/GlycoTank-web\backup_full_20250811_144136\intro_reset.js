﻿(function(){
  function hasFlag(){
    var qs = (location.search||"").toLowerCase();
    return qs.indexOf("resetintro=1")>-1 || qs.indexOf("intro=1")>-1;
  }
  function openIntro(){
    try{ localStorage.removeItem("glycotank_onboard_seen"); }catch(e){}
    if (typeof window.GT_inlineOpen === "function") {
      window.GT_inlineOpen();
    } else {
      var ov = document.getElementById("onboardOverlay");
      if (ov){
        ov.hidden = false;
        ov.style.display = "";
        ov.style.pointerEvents = "auto";
        document.body.style.overflow = "hidden";
      }
    }
  }
  if (hasFlag()){
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", openIntro);
    } else {
      openIntro();
    }
  }
})();
