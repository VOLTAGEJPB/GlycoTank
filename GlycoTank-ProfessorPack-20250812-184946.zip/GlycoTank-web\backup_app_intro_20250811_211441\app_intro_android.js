﻿(function(){
  // Show only in Android app (not website)
  function isAndroidApp(){
    try{ if (window.Capacitor && typeof Capacitor.getPlatform==="function"){ return Capacitor.getPlatform()==="android"; } }catch(e){}
    var ua=(navigator.userAgent||"");
    return /Android/i.test(ua) && /wv|Version\/\d+\.\d+ Chrome\/\d+/.test(ua);
  }
  var SEEN_KEY="glycotank_onboard_seen_app";

  function slides(){ return Array.prototype.slice.call(document.querySelectorAll(".onSlide")); }
  function activeIndex(){ var s=slides(); for(var i=0;i<s.length;i++){ if(s[i].classList.contains("active")) return i; } return 0; }
  function setStep(n){
    var s=slides(); if(!s.length) return;
    var max=s.length-1; if(n<0) n=0; if(n>max) n=max;
    for(var i=0;i<s.length;i++){ s[i].classList.toggle("active", i===n); }
    var back=document.getElementById("onBack"); if(back) back.disabled=(n===0);
    var next=document.getElementById("onNext"); if(next) next.textContent=(n===max)?"Let's go":"Next";
    var dots=document.getElementById("onDots"); if(dots){ dots.innerHTML=""; for(var k=0;k<s.length;k++){ var d=document.createElement("div"); d.className="dot"+(k===n?" active":""); dots.appendChild(d);} }
  }
  function closeIntro(){
    var ov=document.getElementById("onboardOverlay"); if(!ov) return;
    ov.setAttribute("hidden",""); ov.setAttribute("aria-hidden","true");
    ov.style.pointerEvents="none"; document.body.style.overflow="";
    try{ localStorage.setItem(SEEN_KEY,"1"); }catch(e){}
  }
  function step(dir){
    var s=slides(); if(!s.length){ closeIntro(); return; }
    var i=activeIndex(); var max=s.length-1;
    if(dir>0){ if(i<max) setStep(i+1); else closeIntro(); }
    else{ setStep(i-1); }
  }

  function ensureMarkup(){
    if(document.getElementById("onboardOverlay")) return;
    var ov=document.createElement("div");
    ov.id="onboardOverlay"; ov.className="onboard-overlay"; ov.setAttribute("hidden",""); ov.setAttribute("aria-hidden","true");
    ov.innerHTML =
      '<div class="onboard" role="dialog" aria-labelledby="onTitle" aria-modal="true">'+
        '<button class="onX" id="onClose" aria-label="Close">x</button>'+
        '<h2 class="onTitle" id="onTitle">GlycoTank 101</h2>'+
        '<div class="onSlides">'+
          '<div class="onSlide active" data-i="0"><div class="onBody">'+
            '<p><strong>What is Glyco?</strong> Your estimated glycogen fuel tank (grams).</p>'+
            '<ul>'+
              '<li>Meals add: carbs x uptake% (example: 80 g x 85% -> +68 g)</li>'+
              '<li>Workouts subtract: hard sets x set-cost; cardio mins x g/min x intensity</li>'+
              '<li>Low tank -> easier day or add carbs. High tank -> you are ready to push.</li>'+
            '</ul>'+
          '</div></div>'+
          '<div class="onSlide" data-i="1"><div class="onBody">'+
            '<p><strong>How to use it</strong></p>'+
            '<ul>'+
              '<li>Log meals to fill Protein/Fiber bars and raise Glyco.</li>'+
              '<li>Log sets/cardio to deplete Glyco with realistic costs.</li>'+
              '<li>Planner: enter tomorrow\'s sets/mins for a smart carb budget.</li>'+
            '</ul>'+
          '</div></div>'+
          '<div class="onSlide" data-i="2"><div class="onBody">'+
            '<p><strong>Make it yours</strong></p>'+
            '<ul>'+
              '<li>Personalize: weight/goal/training -> tailored Protein, Fiber, Carb, and Glyco settings.</li>'+
              '<li>Favorites: one-tap meals and sessions.</li>'+
              '<li>Local-only: your data stays on your device.</li>'+
            '</ul>'+
          '</div></div>'+
        '</div>'+
        '<div class="onNav">'+
          '<button class="btn ghost" id="onBack" disabled>Back</button>'+
          '<div class="dots" id="onDots"></div>'+
          '<button class="btn primary" id="onNext">Next</button>'+
        '</div>'+
      '</div>';
    document.body.appendChild(ov);
  }

  function bindControls(){
    var next=document.getElementById("onNext");
    var back=document.getElementById("onBack");
    var x=document.getElementById("onClose");
    var ov=document.getElementById("onboardOverlay");
    var evs=["click","pointerup","touchend"];
    function wrap(fn){ return function(e){ if(e && e.type!=="click"){ e.preventDefault(); } fn(); }; }
    if(next){ for(var i=0;i<evs.length;i++){ next.addEventListener(evs[i], wrap(function(){ step(1); }), {passive:false}); } }
    if(back){ for(var j=0;j<evs.length;j++){ back.addEventListener(evs[j], wrap(function(){ step(-1); }), {passive:false}); } }
    if(x){ for(var k=0;k<evs.length;k++){ x.addEventListener(evs[k], wrap(closeIntro), {passive:false}); } }
    if(ov){
      var mo=new MutationObserver(function(){ if(ov.hasAttribute("hidden")){ ov.style.pointerEvents="none"; document.body.style.overflow=""; } });
      mo.observe(ov,{attributes:true,attributeFilter:["hidden","aria-hidden"]});
    }
  }

  function showFirstRunIfAndroid(){
    if(!isAndroidApp()) return;
    var ov=document.getElementById("onboardOverlay"); if(!ov) return;
    var seen=null; try{ seen=localStorage.getItem(SEEN_KEY); }catch(e){}
    if(!seen){
      ov.removeAttribute("hidden"); ov.removeAttribute("aria-hidden");
      ov.style.pointerEvents="auto"; document.body.style.overflow="hidden";
      setStep(0);
    }else{
      ov.setAttribute("hidden",""); ov.style.pointerEvents="none";
    }
  }

  function init(){
    ensureMarkup();
    if(slides().length && !slides().some(function(el){return el.classList.contains("active");})){ slides()[0].classList.add("active"); }
    setStep(activeIndex());
    bindControls();
    showFirstRunIfAndroid();
  }
  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", init); } else { init(); }
})();
