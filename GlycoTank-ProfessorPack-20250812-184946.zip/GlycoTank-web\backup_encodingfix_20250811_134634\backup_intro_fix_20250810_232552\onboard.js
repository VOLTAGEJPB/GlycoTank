﻿(function(){
  const KEY="glycotank_onboard_seen";

  function loadState(){ try{ return JSON.parse(localStorage.getItem("glycotank")||"{}"); }catch(e){ return {}; } }
  function ensureSettings(s){
    s=s||{}; s.settings=Object.assign({proteinTarget:140,fiberTarget:28,carbGuide:250,glycoCap:400,uptakePct:85,setCost:6.0,cardioGpmIntensity1:0.33}, s.settings||{});
    return s.settings;
  }

  function qs(id){ return document.getElementById(id); }
  function all(sel){ return Array.from(document.querySelectorAll(sel)); }

  function setNums(){
    const st = ensureSettings(loadState());
    const el = qs("onNums");
    if(!el) return;
    el.textContent = `Current defaults → Set cost: ${(+st.setCost||0).toFixed(1)} g • Cardio: ${(+st.cardioGpmIntensity1||0).toFixed(2)} g/min • Uptake: ${Math.round(+st.uptakePct||0)}% • Glyco cap: ${Math.round(+st.glycoCap||0)} g`;
  }

  function makeDots(n, i){
    const wrap=qs("onDots"); if(!wrap) return;
    wrap.innerHTML=""; for(let k=0;k<n;k++){ const d=document.createElement("div"); d.className="dot"+(k===i?" active":""); wrap.appendChild(d); }
  }

  function show(i){
    const slides = all(".onSlide");
    slides.forEach((s,idx)=> s.classList.toggle("active", idx===i));
    makeDots(slides.length, i);

    const back=qs("onBack"), next=qs("onNext");
    if(back) back.disabled = i===0;
    if(next){
      next.textContent = (i===slides.length-1) ? "Let’s go" : "Next";
      next.dataset.step = String(i);
    }
  }

  function open(){
    const ov=qs("onboardOverlay"); if(!ov) return;
    setNums(); show(0);
    ov.hidden=false;
    document.body.style.overflow="hidden";
  }
  function close(){
    const ov=qs("onboardOverlay"); if(!ov) return;
    ov.hidden=true;
    document.body.style.overflow="";
    try{ localStorage.setItem(KEY, JSON.stringify({seen:true, ts:Date.now()})); }catch(e){}
  }

  function maybeShow(){
    // Show once, or when ?intro=1 is in the URL
    const force = new URLSearchParams(location.search).get("intro")==="1";
    let seen=false; try{ seen = JSON.parse(localStorage.getItem(KEY)||"{}").seen===true; }catch(e){}
    if(!seen || force){ open(); }
  }

  function hook(){
    const back=qs("onBack"), next=qs("onNext"), closeBtn=qs("onClose");
    back && back.addEventListener("click", ()=> {
      const i = Math.max(0, (parseInt(next?.dataset.step||"0")||0) - 1);
      show(i);
    });
    next && next.addEventListener("click", ()=>{
      const slides=all(".onSlide");
      const i = Math.min(slides.length-1, (parseInt(next?.dataset.step||"0")||0) + 1);
      show(i);
      if(i===slides.length-1 && next.textContent==="Let’s go"){ close(); }
      // If already on last, clicking again closes
      if(i===slides.length-1 && next.textContent!=="Next"){ next.textContent="Let’s go"; }
    });
    closeBtn && closeBtn.addEventListener("click", close);
    // Close by clicking outside
    const ov=qs("onboardOverlay");
    ov && ov.addEventListener("click", (e)=>{ if(e.target===ov) close(); });

    // Keep numbers in slide 3 current when settings change
    window.addEventListener("storage", (ev)=>{ if(ev.key==="glycotank") setNums(); });

    maybeShow();
  }

  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", hook); } else { hook(); }
}window.GT_onboardOpen=open; window.GT_onboardReset=function(){ try{ localStorage.removeItem("glycotank_onboard_seen"); }catch(e){}; open(); }; })();

