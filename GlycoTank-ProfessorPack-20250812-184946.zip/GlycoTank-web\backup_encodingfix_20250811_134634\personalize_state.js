﻿(function(){
  const KEY = "glycotank_personalize_state";
  const FIELDS = [
    "pzUnits","pzWeight","pzAge","pzSex",
    "pzHtUnits","pzHeightCm","pzHeightFt","pzHeightIn",
    "pzGoal","pzWeeklyLb","pzDays","pzAvgSets","pzCardio","pzInt","pzLowCarb"
  ];

  function getState(){ try { return JSON.parse(localStorage.getItem(KEY)||"{}"); } catch(e){ return {}; } }
  function saveState(){
    const s = {};
    FIELDS.forEach(id=>{
      const el = document.getElementById(id);
      if(!el) return;
      s[id] = (el.type==="checkbox") ? !!el.checked : (el.value ?? "");
    });
    localStorage.setItem(KEY, JSON.stringify(s));
  }
  function restore(){
    const s = getState();
    FIELDS.forEach(id=>{
      const el = document.getElementById(id);
      if(!el || s[id]===undefined) return;
      if(el.type==="checkbox") el.checked = !!s[id]; else el.value = s[id];
    });
    // Make sure the height UI toggles correctly, then force a recalc
    const htUnits = document.getElementById("pzHtUnits");
    if(htUnits){ htUnits.dispatchEvent(new Event("change",{bubbles:true})); }
    const any = document.getElementById("pzWeight") || document.getElementById("pzDays") || document.getElementById("pzAvgSets");
    if(any){ any.dispatchEvent(new Event("input",{bubbles:true})); }
  }

  function hook(){
    // Save on any change
    FIELDS.forEach(id=>{
      const el = document.getElementById(id);
      if(!el) return;
      ["input","change"].forEach(evt=> el.addEventListener(evt, saveState));
    });
    restore();
  }

  if (document.readyState==="loading") { document.addEventListener("DOMContentLoaded", hook); } else { hook(); }

  // Also restore whenever the Personalize tab is opened
  const nav = document.getElementById("nav");
  if(nav){
    nav.addEventListener("click", function(e){
      const b = e.target && e.target.closest && e.target.closest("button[data-tab]");
      if(b && b.dataset.tab==="personalize"){ setTimeout(restore, 0); }
    });
  }
})();

