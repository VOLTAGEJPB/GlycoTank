﻿(function(){
  function $$(id){return document.getElementById(id)}
  function num(v){var n=parseFloat((v??"").toString().trim());return isNaN(n)?0:n}
  function kgFrom(x,units){var n=num(x);return (units==="lb")? n*0.453592 : n}
  function cmFrom(mode,cm,ft,inch){return (mode==="ftin")? ((num(ft)*12+num(inch))*2.54) : num(cm)}

  // Mifflin–St Jeor BMR
  function bmrMSJ(kg, cm, age, sex){
    if(!kg||!cm){return 0}
    var base = 10*kg + 6.25*cm - 5*(age||30)
    return Math.round(sex==="f" ? base - 161 : base + 5)
  }
  function kcalFromMETs(kg, MET, mins){ return (MET*3.5*kg/200)*(mins||0) }
  function strengthMins(avgSets){ return (avgSets||0)*2 } // ~2 min per hard set

  function computeFromForm(){
    var units=($$("pzUnits")?.value)||"kg"
    var kg   =kgFrom($$("pzWeight")?.value, units)
    var sex  =($$("pzSex")?.value)||"m"
    var age  =num($$("pzAge")?.value)||30
    var htU  =($$("pzHtUnits")?.value)||"cm"
    var cm   =cmFrom(htU, $$("pzHeightCm")?.value, $$("pzHeightFt")?.value, $$("pzHeightIn")?.value)
    var goal =($$("pzGoal")?.value)||"maintain"
    var lbwk = num($$("pzWeeklyLb")?.value); if(lbwk<-2) lbwk=-2; if(lbwk>2) lbwk=2
    var days = num($$("pzDays")?.value)||3
    var sets = num($$("pzAvgSets")?.value)||12
    var cardio=num($$("pzCardio")?.value)||0
    var int  = num($$("pzInt")?.value)||3
    var lowC = !!($$("pzLowCarb")?.checked)

    var bmr  = bmrMSJ(kg, cm, age, sex)
    var base = bmr*1.20

    var strengthWkMin = strengthMins(sets)*days
    var kcalStrengthWk = kcalFromMETs(kg, 3.5, strengthWkMin)
    var cardioMET = [0,3,5,7,9,11][int] || 5
    var kcalCardioWk = kcalFromMETs(kg, cardioMET, cardio)
    var exDaily = (kcalStrengthWk + kcalCardioWk)/7
    var tdee = Math.round(base + exDaily)
    var adj  = Math.round((lbwk*3500)/7) // kcal/day
    var kcalTarget = Math.max(1200, tdee + adj)

    var pPerKg = (goal==="cut") ? (Math.abs(lbwk)>=0.75 ? 2.2 : 2.0) : (goal==="gain"?1.8:2.0)
    var proteinTarget = Math.round(kg * pPerKg)
    var fatPerKg = (goal==="cut")?0.6:(goal==="gain"?1.0:0.8)
    var fatG = Math.round(kg * fatPerKg)
    var fiberTarget = Math.round(Math.max(20, Math.min(45, 14*(kcalTarget/1000))))
    var carbsLeft = Math.max(0, Math.round((kcalTarget - (4*proteinTarget + 9*fatG)) / 4))
    var carbGuide = carbsLeft

    var glycoCap = Math.round(Math.max(300, Math.min(600, 350 + (kg-70)*1.8 + days*12 + (cardio/4))))
    var uptakePct = (goal==="gain")?90:((goal==="cut"||lowC)?80:85)
    var setCost = Math.max(4.5, Math.min(7.5, 5.5 + (kg>90?0.7:(kg<65?-0.5:0))))
    var cardioGpmIntensity1 = (kg<65)?0.25:(kg>90?0.36:0.33)

    return { proteinTarget, fiberTarget, carbGuide, glycoCap, uptakePct, setCost, cardioGpmIntensity1 }
  }

  var throttle=null
  function applyNow(){
    if(throttle){ clearTimeout(throttle) }
    throttle = setTimeout(function(){
      try{
        var rec = computeFromForm()
        // 1) Update localStorage
        var s; try{ s=JSON.parse(localStorage.getItem("glycotank")||"{}") }catch(_){ s={} }
        s.settings = Object.assign({
          proteinTarget:140, fiberTarget:28, carbGuide:250, glycoCap:400,
          uptakePct:85, setCost:6.0, cardioGpmIntensity1:0.33
        }, s.settings||{})
        s.meta = Object.assign({ userSetSettings:false }, s.meta||{})
        Object.assign(s.settings, rec)
        s.meta.userSetSettings = true
        localStorage.setItem("glycotank", JSON.stringify(s))

        // 2) Update in-memory state from app.js (so Settings shows values immediately)
        if (window.state && window.state.settings){
          Object.assign(window.state.settings, rec)
          window.state.meta = Object.assign({userSetSettings:true}, window.state.meta||{})
          // Re-render Settings/Dashboard if those fns exist
          if (typeof window.renderSettings === "function") { try{ window.renderSettings() }catch(_){} }
          if (typeof window.renderDashboard === "function"){ try{ window.renderDashboard() }catch(_){} }
        }

        // 3) Remove the "Using defaults" hint if it's still there
        var dh=document.getElementById("defaultsHint"); if(dh){ dh.remove() }
      }catch(e){ console.warn("autosync apply failed", e) }
    }, 180)
  }

  // Wire up all Personalize inputs
  var ids = ["pzUnits","pzWeight","pzAge","pzSex","pzHtUnits","pzHeightCm","pzHeightFt","pzHeightIn","pzGoal","pzWeeklyLb","pzDays","pzAvgSets","pzCardio","pzInt","pzLowCarb"]
  function hook(){
    ids.forEach(function(id){
      var el=$$(id); if(!el) return
      ;["input","change"].forEach(function(evt){ el.addEventListener(evt, applyNow) })
    })
    applyNow()
  }

  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", hook) } else { hook() }

  // Also ensure re-apply when opening Settings or Personalize tabs
  var nav=document.getElementById("nav")
  if(nav){
    nav.addEventListener("click", function(e){
      var b = e.target && e.target.closest && e.target.closest("button[data-tab]")
      if(!b) return
      if(b.dataset.tab==="settings" || b.dataset.tab==="personalize"){ setTimeout(applyNow, 0) }
    })
  }
})();

