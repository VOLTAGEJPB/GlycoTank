﻿(function(){
  function $(s){return document.querySelector(s);}
  function all(s){return Array.from(document.querySelectorAll(s));}
  function slides(){return all(".onSlide");}
  function curIndex(){ var s=slides(); for(var i=0;i<s.length;i++){ if(s[i].classList.contains("active")) return i; } return 0; }
  function setStep(n){
    var s=slides(); if(!s.length) return;
    var last=s.length-1; if(n<0) n=0; if(n>last) n=last;
    s.forEach(function(el,i){ el.classList.toggle("active", i===n); });
    var back=$("#onBack"); if(back) back.disabled=(n===0);
    var next=$("#onNext"); if(next) next.textContent=(n===last)?"Let\u2019s go":"Next";
    var dots=$("#onDots"); if(dots){ dots.innerHTML=""; for(var i=0;i<=last;i++){ var d=document.createElement("div"); d.className="dot"+(i===n?" active":""); dots.appendChild(d);} }
  }
  function closeIntro(){
    var ov=$("#onboardOverlay"); if(!ov) return;
    ov.hidden=true; ov.style.display="none"; ov.style.pointerEvents="none";
    document.body.style.overflow="";
    try{ localStorage.setItem("glycotank_onboard_seen", JSON.stringify({seen:true,ts:Date.now()})); }catch(_){}
  }
  function openIntro(){
    var ov=$("#onboardOverlay"); if(!ov) return;
    ov.hidden=false; ov.style.display=""; ov.style.pointerEvents="auto";
    document.body.style.overflow="hidden";
    setStep(0);
  }
  function step(dir){
    var s=slides(); if(!s.length){ closeIntro(); return; }
    var i=curIndex(), last=s.length-1;
    if(dir>0 && i>=last){ closeIntro(); return; }   // ONLY close when actually on last
    setStep(i + (dir>0?1:-1));
  }

  function bind(){
    var n=$("#onNext"), b=$("#onBack"), x=$("#onClose");
    if(n){ n.onclick=function(e){ e.preventDefault(); step(1); return false; }; ["pointerup","touchend"].forEach(function(ev){ n.addEventListener(ev,function(e){ e.preventDefault(); step(1); },{passive:false}); }); }
    if(b){ b.onclick=function(e){ e.preventDefault(); step(-1); return false; }; ["pointerup","touchend"].forEach(function(ev){ b.addEventListener(ev,function(e){ e.preventDefault(); step(-1); },{passive:false}); }); }
    if(x){ x.onclick=function(e){ e.preventDefault(); closeIntro(); return false; }; ["pointerup","touchend"].forEach(function(ev){ x.addEventListener(ev,function(e){ e.preventDefault(); closeIntro(); },{passive:false}); }); }
  }

  // Export for helpers
  window.GT_inlineOpen  = openIntro;
  window.GT_inlineClose = closeIntro;
  window.GT_inlineStep  = step;

  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", function(){ bind(); setStep(0); }); }
  else { bind(); setStep(0); }
})();
