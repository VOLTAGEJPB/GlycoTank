﻿(function(){
  function load(){ try { return JSON.parse(localStorage.getItem("glycotank")||"{}"); } catch(e){ return {}; } }
  function save(s){ localStorage.setItem("glycotank", JSON.stringify(s)); }
  function ensure(s){
    s = s||{};
    s.settings = Object.assign({
      proteinTarget:140, fiberTarget:28, carbGuide:250, glycoCap:400,
      uptakePct:85, setCost:6.0, cardioGpmIntensity1:0.33
    }, s.settings||{});
    s.meta = Object.assign({ userSetSettings:false }, s.meta||{});
    return s;
  }
  function usingDefaults(){ return !ensure(load()).meta.userSetSettings; }
  function hintText(){
    var set = ensure(load()).settings;
    return "Using defaults (" + (set.proteinTarget||0) + "g protein / " +
           (set.fiberTarget||0) + "g fiber / " +
           (set.carbGuide||0) + "g carbs)";
  }
  function removeHint(){ var h=document.getElementById("defaultsHint"); if(h) h.remove(); }
  function addHint(){
    if(!usingDefaults()){ removeHint(); return; }
    var h = document.getElementById("defaultsHint");
    var fiberDetail = document.getElementById("fiberDetail");
    if(!h){
      h = document.createElement("div");
      h.id = "defaultsHint";
      h.className = "smallmuted";
      if(fiberDetail && fiberDetail.parentNode){
        fiberDetail.parentNode.insertBefore(h, fiberDetail.nextSibling);
      } else {
        // fallback: append to first dashboard card
        var card = document.querySelector("#tab-dash .card");
        (card||document.body).appendChild(h);
      }
    }
    h.textContent = hintText();
  }
  function onSaveSettings(){
    var s = ensure(load());
    s.meta.userSetSettings = true;
    save(s);
    removeHint();
  }
  function onResetSettings(){
    var s = ensure(load());
    s.meta.userSetSettings = false;
    save(s);
    addHint();
  }
  function hook(){
    addHint(); // initial
    // Re-show when navigating back to Dashboard
    var nav=document.getElementById("nav");
    if(nav){
      nav.addEventListener("click", function(e){
        var btn = e.target && e.target.closest && e.target.closest("button[data-tab]");
        if(btn && btn.dataset.tab==="dash"){ setTimeout(addHint,0); }
      });
    }
    // Toggle hint after settings actions
    var saveBtn = document.getElementById("saveSettings");
    if(saveBtn){ saveBtn.addEventListener("click", function(){ setTimeout(onSaveSettings,0); }); }
    var resetBtn = document.getElementById("resetSettings") || document.getElementById("resetDefaults");
    if(resetBtn){ resetBtn.addEventListener("click", function(){ setTimeout(onResetSettings,0); }); }
  }
  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", hook); } else { hook(); }
})();

