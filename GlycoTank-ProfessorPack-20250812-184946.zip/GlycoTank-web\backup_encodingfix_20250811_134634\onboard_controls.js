﻿(function(){
  function openIntro(){
    if (window.GT_onboardReset) { window.GT_onboardReset(); return; }
    var ov=document.getElementById("onboardOverlay");
    if(ov){ ov.hidden=false; document.body.style.overflow="hidden"; }
  }
  function clickHandler(e){
    var t = e.target && e.target.closest && e.target.closest("#showIntroBtn, #showIntroLink");
    if(!t) return;
    e.preventDefault();
    openIntro();
  }
  document.addEventListener("click", clickHandler);
})();

