﻿(function(){
  function showTab(tab){
    try{
      document.querySelectorAll(".tab").forEach(function(e){ e.hidden = true; });
      var t = document.getElementById("tab-"+tab); if(t){ t.hidden = false; }
      document.querySelectorAll("#nav button").forEach(function(b){
        b.classList.toggle("active", b.dataset.tab===tab);
      });
      if (tab==="dash"     && typeof window.renderDashboard==="function") window.renderDashboard();
      if (tab==="history"  && typeof window.renderHistory==="function")  window.renderHistory();
      if (tab==="settings" && typeof window.renderSettings==="function") window.renderSettings();
    }catch(e){ console && console.warn && console.warn("nav_rescue showTab err", e); }
  }
  function bindNav(){
    var nav = document.getElementById("nav");
    if(!nav) return;
    // Remove any previous handler by cloning (safe rebind)
    var clone = nav.cloneNode(true);
    nav.parentNode.replaceChild(clone, nav);
    clone.addEventListener("click", function(e){
      var btn = e.target && e.target.closest && e.target.closest("button[data-tab]");
      if(!btn) return;
      e.preventDefault();
      showTab(btn.dataset.tab);
    }, {passive:false});
    // ensure default landing tab is visible
    var active = clone.querySelector("button.active");
    showTab(active ? active.dataset.tab : "dash");
  }
  if (document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", bindNav); } else { bindNav(); }
  window.GT_showTab = showTab; // optional global
})();

