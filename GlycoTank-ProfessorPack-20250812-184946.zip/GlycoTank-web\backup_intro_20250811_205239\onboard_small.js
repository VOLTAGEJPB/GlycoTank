﻿(function(){
  function $(q){ return document.querySelector(q); }
  function $id(id){ return document.getElementById(id); }

  function ensureMarkup(){
    if ($id("onboardOverlay")) return;
    var ov = document.createElement("div");
    ov.id = "onboardOverlay";
    ov.className = "onboard-overlay";
    ov.setAttribute("hidden","");
    ov.innerHTML =
      '<div class="onboard" role="dialog" aria-labelledby="onTitle" aria-modal="true">'+
        '<button class="onX" id="onClose" aria-label="Close">x</button>'+
        '<h2 class="onTitle" id="onTitle">GlycoTank 101</h2>'+
        '<div class="onSlides">'+
          '<div class="onSlide active" data-i="0">'+
            '<div class="onBody">'+
              '<p><strong>What is Glyco?</strong> Your estimated glycogen fuel tank (grams) powering daily training and energy.</p>'+
              '<ul>'+
                '<li>Meals add: carbs x uptake% (e.g., 80 g x 85% -> +68 g)</li>'+
                '<li>Workouts subtract: hard sets x set-cost; cardio minutes x g/min x intensity</li>'+
                '<li>Low tank -> easier day or add carbs. High tank -> you are primed to push.</li>'+
              '</ul>'+
            '</div>'+
          '</div>'+
          '<div class="onSlide" data-i="1">'+
            '<div class="onBody">'+
              '<p><strong>Why it matters</strong></p>'+
              '<ul>'+
                '<li>Steadier workouts when fuel matches training.</li>'+
                '<li>Fewer flat days from under-fueling.</li>'+
                '<li>Simple, local-first tracking with clear daily targets.</li>'+
              '</ul>'+
            '</div>'+
          '</div>'+
          '<div class="onSlide" data-i="2">'+
            '<div class="onBody">'+
              '<p><strong>Make it yours</strong></p>'+
              '<ul>'+
                '<li>Personalize -> tailored Protein, Fiber, Carb, and Glyco settings.</li>'+
                '<li>Favorites -> one-tap meals and sessions.</li>'+
                '<li>Local-only -> your data stays on your device.</li>'+
              '</ul>'+
            '</div>'+
          '</div>'+
        '</div>'+
        '<div class="onNav">'+
          '<button class="btn ghost" id="onBack" disabled>Back</button>'+
          '<div class="dots" id="onDots"></div>'+
          '<button class="btn primary" id="onNext">Next</button>'+
        '</div>'+
      '</div>';
    document.body.appendChild(ov);
  }

  function slides(){ return Array.from(document.querySelectorAll(".onSlide")); }
  function activeIndex(){ var s=slides(); for(var i=0;i<s.length;i++){ if(s[i].classList.contains("active")) return i; } return 0; }
  function setStep(n){
    var s=slides(); if(!s.length) return;
    n = Math.max(0, Math.min(s.length-1, n));
    s.forEach(function(el,i){ el.classList.toggle("active", i===n); });
    var back=$id("onBack"); if(back) back.disabled = (n===0);
    var next=$id("onNext"); if(next) next.textContent = (n===s.length-1) ? "Let's go" : "Next";
    var dots=$id("onDots");
    if(dots){ dots.innerHTML=""; for(var i=0;i<s.length;i++){ var d=document.createElement("div"); d.className="dot"+(i===n?" active":""); dots.appendChild(d); } }
  }
  function closeIntro(){
    var ov=$id("onboardOverlay"); if(!ov) return;
    ov.setAttribute("hidden",""); ov.setAttribute("aria-hidden","true");
    ov.style.pointerEvents="none"; document.body.style.overflow="";
    try{ localStorage.setItem("glycotank_onboard_seen","1"); }catch(_){}
  }
  function step(dir){
    var s=slides(); if(!s.length){ closeIntro(); return; }
    var i=activeIndex();
    if (dir>0){ if (i < s.length-1) setStep(i+1); else closeIntro(); }
    else { setStep(i-1); }
  }
  function bindControls(){
    var next=$id("onNext"), back=$id("onBack"), x=$id("onClose"), ov=$id("onboardOverlay");
    ["click","pointerup","touchend"].forEach(function(ev){
      if(next) next.addEventListener(ev, function(e){ if(ev!=="click") e.preventDefault(); step(1); }, {passive:false});
      if(back) back.addEventListener(ev, function(e){ if(ev!=="click") e.preventDefault(); step(-1); }, {passive:false});
      if(x)    x.addEventListener(ev, function(e){ if(ev!=="click") e.preventDefault(); closeIntro(); }, {passive:false});
    });
    if (ov){
      var mo = new MutationObserver(function(){ if(ov.hasAttribute("hidden")) ov.style.pointerEvents="none"; });
      mo.observe(ov, { attributes:true, attributeFilter:["hidden","aria-hidden"] });
    }
  }
  function showIfFirstRun(){
    var ov=$id("onboardOverlay"); if(!ov) return;
    var seen=null; try{ seen = localStorage.getItem("glycotank_onboard_seen"); }catch(_){}
    if (!seen){ ov.removeAttribute("hidden"); ov.removeAttribute("aria-hidden"); ov.style.pointerEvents="auto"; document.body.style.overflow="hidden"; setStep(0); }
    else { ov.setAttribute("hidden",""); ov.style.pointerEvents="none"; }
  }
  function init(){ ensureMarkup(); if(slides().length && !slides().some(function(el){return el.classList.contains("active")})) slides()[0].classList.add("active"); setStep(activeIndex()); bindControls(); showIfFirstRun(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
