﻿(function(){
  function q(s){ return document.querySelector(s); }
  function qa(s){ return Array.from(document.querySelectorAll(s)); }
  function slides(){ return qa(".onSlide"); }
  function curIndex(){
    var s=slides();
    for (var i=0;i<s.length;i++){ if (s[i].classList.contains("active")) return i; }
    return 0;
  }
  function setStep(n){
    var s=slides(); if(!s.length) return;
    var last = s.length-1;
    if (n<0) n=0; if (n>last) n=last;
    s.forEach(function(el,i){ el.classList.toggle("active", i===n); });
    var back=q("#onBack"); if(back) back.disabled = (n===0);
    var next=q("#onNext"); if(next) next.textContent = (n===last) ? "Let\u2019s go" : "Next";
    var dots=q("#onDots"); if(dots){ dots.innerHTML=""; for(var i=0;i<=last;i++){ var d=document.createElement("div"); d.className="dot"+(i===n?" active":""); dots.appendChild(d);} }
  }
  function closeIntro(){
    var ov=q("#onboardOverlay"); if(!ov) return;
    ov.hidden=true; ov.style.display="none"; ov.style.pointerEvents="none";
    document.body.style.overflow="";
    try{ localStorage.setItem("glycotank_onboard_seen", JSON.stringify({seen:true,ts:Date.now()})); }catch(_){}
  }
  function openIntro(){
    var ov=q("#onboardOverlay"); if(!ov) return;
    ov.hidden=false; ov.style.display=""; ov.style.pointerEvents="auto";
    document.body.style.overflow="hidden";
    setStep(0);
  }
  function step(dir){
    var s=slides(); if(!s.length){ closeIntro(); return; }
    var i = curIndex();
    var last = s.length-1;
    // Only close if you're already on the last slide and you press Next
    if (dir>0 && i>=last) { closeIntro(); return; }
    setStep(i + (dir>0? 1 : -1));
  }

  // Hard-bind handlers (overrides any older ones)
  function bind(){
    var next=q("#onNext"), back=q("#onBack"), x=q("#onClose");
    if(next){ next.onclick=function(e){ e.preventDefault(); step(1); return false; }; ["pointerup","touchend"].forEach(ev=>next.addEventListener(ev,function(e){ e.preventDefault(); step(1); },{passive:false})); }
    if(back){ back.onclick=function(e){ e.preventDefault(); step(-1); return false; }; ["pointerup","touchend"].forEach(ev=>back.addEventListener(ev,function(e){ e.preventDefault(); step(-1); },{passive:false})); }
    if(x){ x.onclick=function(e){ e.preventDefault(); closeIntro(); return false; }; ["pointerup","touchend"].forEach(ev=>x.addEventListener(ev,function(e){ e.preventDefault(); closeIntro(); },{passive:false})); }
  }

  // Expose globals (optional)
  window.GT_inlineOpen  = openIntro;
  window.GT_inlineClose = closeIntro;
  window.GT_inlineStep  = step;

  function firstRunMaybe(){
    try{
      var seen = JSON.parse(localStorage.getItem("glycotank_onboard_seen")||"{}").seen===true;
      if(!seen) openIntro();
    }catch(_){ openIntro(); }
  }

  if (document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded", function(){ bind(); setStep(0); });
  } else { bind(); setStep(0); }
  // Do not auto-open here; intro_reset.js or your first-run logic can handle that.
})();
