﻿(function(){
  function load(){ try { return JSON.parse(localStorage.getItem("glycotank")||"{}"); } catch(e){ return {}; } }
  function usingDefaults(){ var s=load(); return !(s.meta && s.meta.userSetSettings); }

  var ids = ["sProtein","sFiber","sCarb","sGlycoCap","sUptake","sSetCost","sCardioGpm"];
  function maybeBlank(){
    if (!usingDefaults()) return;  // once personalized, show actual values
    ids.forEach(function(id){ var el=document.getElementById(id); if(el) el.value=""; });
  }
  function hook(){
    var nav=document.getElementById("nav");
    if(nav){
      nav.addEventListener("click", function(e){
        var btn = e.target && e.target.closest && e.target.closest("button[data-tab]");
        if(btn && btn.dataset.tab==="settings"){ setTimeout(maybeBlank,0); }
      });
    }
    maybeBlank(); // on initial load
  }
  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", hook); } else { hook(); }
})();

