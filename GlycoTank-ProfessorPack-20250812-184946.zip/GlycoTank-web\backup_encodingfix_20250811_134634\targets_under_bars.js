﻿(function(){
  function load(){ try { return JSON.parse(localStorage.getItem("glycotank")||"{}"); } catch(e){ return {}; } }
  function ensure(s){
    s = s||{};
    s.settings = Object.assign({
      proteinTarget:140, fiberTarget:28, carbGuide:250, glycoCap:400,
      uptakePct:85, setCost:6.0, cardioGpmIntensity1:0.33
    }, s.settings||{});
    s.meta = Object.assign({ userSetSettings:false }, s.meta||{});
    return s;
  }
  function setText(id, txt){ var el=document.getElementById(id); if(el) el.textContent = txt; }

  function updateTargetsLines(){
    var st = ensure(load()).settings;
    setText("proteinTargetLine", "Target: " + (st.proteinTarget||0) + " g");
    setText("fiberTargetLine",   "Target: " + (st.fiberTarget||0)   + " g");
  }

  function hook(){
    updateTargetsLines();
    // Refresh when returning to Dashboard
    var nav=document.getElementById("nav");
    if(nav){
      nav.addEventListener("click", function(e){
        var btn = e.target && e.target.closest && e.target.closest("button[data-tab]");
        if(btn && btn.dataset.tab==="dash"){ setTimeout(updateTargetsLines,0); }
      });
    }
    // After Save/Reset in Settings
    var saveBtn = document.getElementById("saveSettings");
    if(saveBtn){ saveBtn.addEventListener("click", function(){ setTimeout(updateTargetsLines,150); }); }
    var resetBtn = document.getElementById("resetSettings") || document.getElementById("resetDefaults");
    if(resetBtn){ resetBtn.addEventListener("click", function(){ setTimeout(updateTargetsLines,150); }); }
  }
  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", hook); } else { hook(); }
})();

