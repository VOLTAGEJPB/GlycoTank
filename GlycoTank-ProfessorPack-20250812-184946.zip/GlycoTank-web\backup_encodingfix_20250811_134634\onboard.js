﻿(function(){
  const KEY = "glycotank_onboard_seen";

  function load(){ try{ return JSON.parse(localStorage.getItem("glycotank")||"{}"); }catch(e){ return {}; } }
  function settings(){ const s=load(); return Object.assign({proteinTarget:140,fiberTarget:28,carbGuide:250,glycoCap:400,uptakePct:85,setCost:6.0,cardioGpmIntensity1:0.33}, s.settings||{}); }

  // DOM helpers
  const $ = (id)=> document.getElementById(id);
  const $$ = (sel)=> Array.from(document.querySelectorAll(sel));

  let step = 0;
  function setNums(){
    const st=settings(); const el=$("onNums"); if(!el) return;
    el.textContent = "Current defaults → Set cost: "
      + (+(st.setCost||0)).toFixed(1) + " g • Cardio: "
      + (+(st.cardioGpmIntensity1||0)).toFixed(2) + " g/min • Uptake: "
      + Math.round(+(st.uptakePct||0)) + "% • Glyco cap: "
      + Math.round(+(st.glycoCap||0)) + " g";
  }

  function show(){
    const slides = $$(".onSlide");
    slides.forEach((s,i)=> s.classList.toggle("active", i===step));
    const back = $("onBack"), next=$("onNext");
    if(back) back.disabled = step===0;
    if(next) next.textContent = (step===slides.length-1) ? "Let\u2019s go" : "Next";
    setNums();
    // dots
    const dotsWrap = $("onDots");
    if(dotsWrap){
      dotsWrap.innerHTML="";
      for(let i=0;i<slides.length;i++){
        const d=document.createElement("div"); d.className="dot"+(i===step?" active":""); dotsWrap.appendChild(d);
      }
    }
  }

  function open(start=0){
    step = start||0;
    const ov=$("onboardOverlay"); if(!ov) return;
    ov.hidden=false; document.body.style.overflow="hidden";
    show();
  }

  function close(){
    const ov=$("onboardOverlay"); if(!ov) return;
    ov.hidden=true; document.body.style.overflow="";
    try{ localStorage.setItem(KEY, JSON.stringify({seen:true, ts:Date.now()})); }catch(e){}
  }

  function maybeShow(){
    const force = new URLSearchParams(location.search).get("intro")==="1";
    let seen=false; try{ seen = JSON.parse(localStorage.getItem(KEY)||"{}").seen===true; }catch(e){}
    if (!seen || force) open(0);
  }

  function hook(){
    const back=$("onBack"), next=$("onNext"), x=$("onClose"), ov=$("onboardOverlay");
    back && back.addEventListener("click", ()=>{ step=Math.max(0, step-1); show(); });
    next && next.addEventListener("click", ()=>{
      const slides = $$(".onSlide");
      if(step < slides.length-1){ step++; show(); }
      else { close(); }
    });
    x && x.addEventListener("click", close);
    ov && ov.addEventListener("click", (e)=>{ if(e.target===ov) close(); });
    document.addEventListener("keydown", (e)=>{ if(e.key==="Escape") close(); });

    // keep numbers fresh if settings change while modal is open
    window.addEventListener("storage", (ev)=>{ if(ev.key==="glycotank") setNums(); });

    maybeShow();
  }

  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", hook); }
  else { hook(); }

  // Public openers (used by footer button / settings link)
  window.GT_onboardOpen = ()=> open(0);
  window.GT_onboardReset = ()=> { try{ localStorage.removeItem(KEY); }catch(e){}; open(0); };
})();

