﻿(function(){
  'use strict';
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const todayStr = () => new Date().toISOString().slice(0,10);
  const clamp = (v,min,max)=> Math.max(min, Math.min(max, v));
  const num = v => { const n=parseFloat(v); return isNaN(n)?0:n; };
  function load(){ try { return JSON.parse(localStorage.getItem('glycotank')||'{}'); } catch(e){ return {}; } }
  function save(state){ localStorage.setItem('glycotank', JSON.stringify(state)); }
  function uid(){ return Math.random().toString(36).slice(2,10); }

  const defaults = {
    workouts:[], meals:[], checks:[],
    workoutFavs:[], mealFavs:[],
    undo:[], glycoHistory:{},
    exerciseCatalog: {
      "Back": ["Pull-up","Chin-up","Bent-over row","Seated cable row","Lat pulldown","Deadlift (back emphasis)"],
      "Arms": ["Barbell curl","Incline dumbbell curl","Hammer curl","Cable triceps pushdown","Skull crusher","Dips (triceps)"],
      "Legs": ["Back squat","Front squat","Leg press","Walking lunge","Romanian deadlift","Leg extension","Leg curl"],
      "Calves": ["Standing calf raise","Seated calf raise","Donkey calf raise"],
      "Lower Body": ["Hip thrust","Good morning","Glute bridge","Bulgarian split squat"],
      "Chest": ["Flat barbell bench","Incline dumbbell press","Dips (chest)","Cable fly"],
      "Shoulders": ["Overhead press","Dumbbell shoulder press","Lateral raise","Rear delt fly"],
      "Core": ["Plank","Hanging leg raise","Cable crunch","Ab wheel rollout"]
    },
    settings: {
      proteinTarget:140, fiberTarget:28, carbGuide:250,
      glycoCap:400, uptakePct:85, setCost:6.0, cardioGpmIntensity1:0.33,
      autosave:false, lastBackup:"", chartDays:14,
      remind:{ hydrate:"", lunch:"", evening:"" }
    }
  };
  const state = Object.assign({}, defaults, load());
  state.settings = Object.assign({}, defaults.settings, state.settings||{});
  state.exerciseCatalog = Object.assign({}, defaults.exerciseCatalog, state.exerciseCatalog||{});

  if('serviceWorker' in navigator){ window.addEventListener('load', ()=> navigator.serviceWorker.register('./service-worker.js')); }
  let deferredPrompt;
  window.addEventListener('beforeinstallprompt', (e)=>{ e.preventDefault(); deferredPrompt=e; const btn=$('#installBtn'); if(btn){ btn.hidden=false; btn.onclick=async()=>{ btn.disabled=true; await deferredPrompt.prompt(); deferredPrompt=null; }; }});

  $$('#nav button').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      $$('#nav button').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      const tab=btn.dataset.tab; $$('.tab').forEach(sec=>sec.hidden=true);
      $('#tab-'+tab).hidden=false;
      if(tab==='dash') renderDashboard();
      if(tab==='history') renderHistory();
      if(tab==='settings') renderSettings();
    });
  });

  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  function dictateTo(inputEl){ if(!SpeechRec){ alert('Speech recognition not supported in this browser.'); return; } const r=new SpeechRec(); r.lang='en-US'; r.interimResults=false; r.maxAlternatives=1; r.onresult = e => { inputEl.value = e.results[0][0].transcript; }; r.start(); }

  const wType=$('#wType'), strengthFields=$('#strengthFields'), cardioFields=$('#cardioFields');
  wType.addEventListener('change', ()=>{ const v=wType.value; strengthFields.hidden = v!=='strength'; cardioFields.hidden = v!=='cardio'; });
  $('#wDate').value = todayStr();
  $('#voiceWorkout').addEventListener('click', e=>{ e.preventDefault(); dictateTo($('#wName')); });

  // Category + exercise dropdowns
  function populateExercises(){
    const cat = $('#wCategory').value;
    const sel = $('#wExercise');
    const list = (state.exerciseCatalog[cat]||[]);
    sel.innerHTML = '<option value=\"\">Exercise…</option>' + list.map(x=>`<option>${x}</option>`).join('');
  }
  $('#wCategory').addEventListener('change', ()=>{
    populateExercises();
    $('#wName').value = ''; $('#wExercise').value='';
  });
  $('#wExercise').addEventListener('change', ()=>{
    const v = $('#wExercise').value; if(v) $('#wName').value = v;
  });
  populateExercises();

  // Meal & Check-in setup
  $('#mDate').value = todayStr(); $('#cDate').value = todayStr();
  $('#voiceMeal').addEventListener('click', e=>{ e.preventDefault(); dictateTo($('#mName')); });

  // Favorites
  function refreshFavs(){
    const wSel=$('#wFavs'), mSel=$('#mFavs');
    if(wSel){ wSel.innerHTML = '<option value=\"\">Favorites…</option>' + (state.workoutFavs||[]).map((f,i)=>`<option value=\"${i}\">${f.label}</option>`).join(''); }
    if(mSel){ mSel.innerHTML = '<option value=\"\">Favorites…</option>' + (state.mealFavs||[]).map((f,i)=>`<option value=\"${i}\">${f.label}</option>`).join(''); }
  }
  refreshFavs();

  $('#wFavs').addEventListener('change', ()=>{
    const idx = parseInt($('#wFavs').value,10); if(isNaN(idx)) return;
    const f = state.workoutFavs[idx]; if(!f) return;
    $('#wType').value = f.type||'strength'; wType.dispatchEvent(new Event('change'));
    if(f.type==='strength'){
      $('#wCategory').value=f.category||''; populateExercises();
      if(f.exercise){ $('#wExercise').value=f.exercise; $('#wName').value=f.exercise; } else { $('#wName').value=f.name||''; }
      $('#wSets').value=f.sets||3; $('#wReps').value=f.reps||5; $('#wWeight').value=f.weight||0;
    } else if(f.type==='cardio'){
      $('#wCardioName').value=f.name||''; $('#wMins').value=f.mins||30; $('#wIntensity').value=f.intensity||3;
    }
    $('#wNotes').value=f.notes||'';
  });
  $('#saveWFav').addEventListener('click', ()=>{
    const type=wType.value;
    const fav = (type==='strength')
      ? {label:($('#wName').value||'Strength'), type, category:$('#wCategory').value||'', exercise:$('#wExercise').value||$('#wName').value, name:$('#wName').value, sets:num($('#wSets').value), reps:num($('#wReps').value), weight:num($('#wWeight').value), notes:$('#wNotes').value}
      : {label:($('#wCardioName').value||'Cardio'), type, name:$('#wCardioName').value, mins:num($('#wMins').value), intensity:num($('#wIntensity').value), notes:$('#wNotes').value};
    state.workoutFavs = state.workoutFavs||[]; state.workoutFavs.push(fav); save(state); refreshFavs(); alert('Saved to favorites.');
  });
  $('#mFavs').addEventListener('click', ()=>{});
  $('#saveMFav').addEventListener('click', ()=>{
    const fav = {label:($('#mName').value||'Meal'), name:$('#mName').value, kcal:num($('#mCalories').value), carbs:num($('#mCarbs').value), protein:num($('#mProtein').value), fat:num($('#mFat').value), fiber:num($('#mFiber').value), notes:$('#mNotes').value};
    state.mealFavs = state.mealFavs||[]; state.mealFavs.push(fav); save(state); refreshFavs(); alert('Saved to favorites.');
  });

  // Parse helpers
  function parseMealNotes(t){
    const g = s=> { const m=t.match(s); return m? num(m[1]) : 0; }
    return { kcal: g(/(?:kcal|cal)\s*(\d+)/i), carbs: g(/(?:c|carb|carbs)\s*(\d+)/i), protein: g(/(?:p|prot|protein)\s*(\d+)/i), fat: g(/(?:f|fat)\s*(\d+)/i), fiber: g(/(?:fib|fiber)\s*(\d+)/i) };
  }
  $('#parseMeal').addEventListener('click', ()=>{
    const t = ($('#mNotes').value||''); const r = parseMealNotes(t);
    if(r.kcal) $('#mCalories').value=r.kcal; if(r.carbs) $('#mCarbs').value=r.carbs; if(r.protein) $('#mProtein').value=r.protein; if(r.fat) $('#mFat').value=r.fat; if(r.fiber) $('#mFiber').value=r.fiber;
  });
  $('#parseWorkout').addEventListener('click', ()=>{
    const t = ($('#wNotes').value||''); const s = t.match(/(\d+)\s*x\s*(\d+)/i); if(s){ $('#wSets').value=s[1]; $('#wReps').value=s[2]; }
    const w = t.match(/@?\s*(\d+(\.\d+)?)\s*(kg|lb)?/i); if(w){ $('#wWeight').value=w[1]; }
    const m = t.match(/(\d+)\s*(min|mins|minutes)/i); if(m){ $('#wMins').value=m[1]; }
  });

  function pushUndo(a){ state.undo=state.undo||[]; state.undo.push(a); if(state.undo.length>25) state.undo.shift(); save(state); }
  $('#undoBtn').addEventListener('click', ()=>{ const last=(state.undo||[]).pop(); if(!last){ alert('Nothing to undo.'); return; } if(last.kind==='workout'){ state.workouts=state.workouts.filter(x=>x.id!==last.id); } if(last.kind==='meal'){ state.meals=state.meals.filter(x=>x.id!==last.id); } save(state); renderDashboard(); renderHistory(); });

  $('#saveWorkout').addEventListener('click', ()=>{
    const date=$('#wDate').value||todayStr();
    const type=wType.value; const notes=$('#wNotes').value.trim();
    let entry;
    if(type==='strength'){
      entry={ id:uid(), date, type,
        category: $('#wCategory').value||'',
        exercise: $('#wExercise').value||'',
        name:($('#wName').value.trim()||$('#wExercise').value||'Strength'),
        sets:num($('#wSets').value), reps:num($('#wReps').value), weight:num($('#wWeight').value), notes };
    } else if(type==='cardio'){
      entry={ id:uid(), date, type, name:($('#wCardioName').value.trim()||'Cardio'), mins:num($('#wMins').value), intensity:clamp(num($('#wIntensity').value)||3,1,5), notes };
    } else {
      entry={ id:uid(), date, type, name:(type[0].toUpperCase()+type.slice(1)), notes };
    }
    state.workouts.push(entry); pushUndo({kind:'workout', id:entry.id}); save(state); clearWorkoutForm(); renderDashboard(); alert('Workout saved.');
  });
  function clearWorkoutForm(){ $('#wName').value=''; $('#wSets').value=3; $('#wReps').value=5; $('#wWeight').value=100; $('#wCardioName').value=''; $('#wMins').value=30; $('#wIntensity').value=3; $('#wNotes').value=''; $('#wDate').value=todayStr(); $('#wCategory').value=''; populateExercises(); $('#wExercise').value=''; }

  $('#saveMeal').addEventListener('click', ()=>{
    const date=$('#mDate').value||todayStr();
    const entry={ id:uid(), date, name:($('#mName').value.trim()||'Meal'),
      kcal:num($('#mCalories').value), carbs:num($('#mCarbs').value), protein:num($('#mProtein').value), fat:num($('#mFat').value), fiber:num($('#mFiber').value),
      notes:$('#mNotes').value.trim()
    };
    state.meals.push(entry); pushUndo({kind:'meal', id:entry.id}); save(state); clearMealForm(); renderDashboard(); alert('Meal saved.');
  });
  function clearMealForm(){ $('#mDate').value=todayStr(); $('#mName').value=''; $('#mCalories').value=''; $('#mCarbs').value=''; $('#mProtein').value=''; $('#mFat').value=''; $('#mFiber').value=''; $('#mNotes').value=''; }

  $('#saveCheckin').addEventListener('click', ()=>{
    const entry={ id:uid(), date:($('#cDate').value||todayStr()), mood:$('#cMood').value, sleep:num($('#cSleep').value), rhr:parseInt($('#cRHR').value||'0',10), notes:$('#cNotes').value.trim() };
    const i = (state.checks||[]).findIndex(x=>x.date===entry.date);
    if(i>=0) state.checks[i]=entry; else state.checks.push(entry);
    save(state); alert('Check-in saved.'); renderDashboard();
  });

  function attachEditHandlers(){
    ['todayMeals','todayWorkouts','history'].forEach(id=>{
      const root = $('#'+id); if(!root) return;
      root.onclick = (e)=>{
        const div = e.target.closest('[data-kind]'); if(!div) return;
        const kind = div.dataset.kind, itemId = div.dataset.id;
        if(kind==='meal'){
          const m = state.meals.find(x=>x.id===itemId); if(!m) return;
          $('#mDate').value=m.date; $('#mName').value=m.name; $('#mCalories').value=m.kcal||''; $('#mCarbs').value=m.carbs||''; $('#mProtein').value=m.protein||''; $('#mFat').value=m.fat||''; $('#mFiber').value=m.fiber||''; $('#mNotes').value=m.notes||'';
          $('#nav [data-tab="meal"]').click();
          const original = $('#saveMeal').onclick;
          $('#saveMeal').onclick = ()=>{
            m.date=$('#mDate').value||todayStr(); m.name=$('#mName').value||'Meal';
            m.kcal=num($('#mCalories').value); m.carbs=num($('#mCarbs').value); m.protein=num($('#mProtein').value); m.fat=num($('#mFat').value); m.fiber=num($('#mFiber').value);
            m.notes=$('#mNotes').value||'';
            save(state); renderDashboard(); renderHistory(); alert('Meal updated.');
            $('#saveMeal').onclick = original; clearMealForm();
          };
        } else if(kind==='workout'){
          const w = state.workouts.find(x=>x.id===itemId); if(!w) return;
          $('#wDate').value=w.date; $('#wType').value=w.type; wType.dispatchEvent(new Event('change'));
          if(w.type==='strength'){
            $('#wCategory').value=w.category||''; populateExercises();
            if(w.exercise){ $('#wExercise').value=w.exercise; }
            $('#wName').value=w.name||''; $('#wSets').value=w.sets||3; $('#wReps').value=w.reps||5; $('#wWeight').value=w.weight||0;
          } else if(w.type==='cardio'){ $('#wCardioName').value=w.name||''; $('#wMins').value=w.mins||30; $('#wIntensity').value=w.intensity||3; }
          $('#wNotes').value=w.notes||'';
          $('#nav [data-tab="workout"]').click();
          const original2 = $('#saveWorkout').onclick;
          $('#saveWorkout').onclick = ()=>{
            w.date=$('#wDate').value||todayStr(); w.type=$('#wType').value;
            if(w.type==='strength'){ w.category=$('#wCategory').value||''; w.exercise=$('#wExercise').value||''; w.name=$('#wName').value||'Strength'; w.sets=num($('#wSets').value); w.reps=num($('#wReps').value); w.weight=num($('#wWeight').value); }
            else if(w.type==='cardio'){ w.name=$('#wCardioName').value||'Cardio'; w.mins=num($('#wMins').value); w.intensity=clamp(num($('#wIntensity').value)||3,1,5); }
            w.notes=$('#wNotes').value||'';
            save(state); renderDashboard(); renderHistory(); alert('Workout updated.');
            $('#saveWorkout').onclick = original2; clearWorkoutForm();
          };
        }
      };
    });
  }

  function computeGlycoForDay(dateStr){
    const cfg=state.settings;
    const yesterday=new Date(dateStr); yesterday.setDate(yesterday.getDate()-1);
    const y=yesterday.toISOString().slice(0,10);
    let start=(state.glycoHistory && state.glycoHistory[y]!=null)?state.glycoHistory[y]:(cfg.glycoCap*0.7);
    const meals=state.meals.filter(m=>m.date===dateStr);
    const added=meals.reduce((sum,m)=> sum+(num(m.carbs)*(cfg.uptakePct/100)), 0);
    const wos=state.workouts.filter(w=>w.date===dateStr);
    let cost=0;
    for(const w of wos){
      if(w.type==='strength'){ cost += (num(w.sets)||0)*cfg.setCost; }
      else if(w.type==='cardio'){ const mins=num(w.mins)||0; const intensity=clamp(num(w.intensity)||1,1,5); cost += mins*cfg.cardioGpmIntensity1*intensity; }
      else { cost += 10; }
    }
    let end = clamp(start + added - cost, 0, cfg.glycoCap); return { start, added, cost, end };
  }
  function rebuildGlycoHistory(days=14){
    state.glycoHistory = state.glycoHistory || {};
    const now=new Date(); const startDate=new Date(now); startDate.setDate(startDate.getDate()-(days-1));
    let prev=state.settings.glycoCap*0.7;
    for(let i=0;i<days;i++){
      const d=new Date(startDate); d.setDate(startDate.getDate()+i);
      const ds=d.toISOString().slice(0,10);
      state.glycoHistory[ds]=prev;
      const {end}=computeGlycoForDay(ds); state.glycoHistory[ds]=end; prev=end;
    }
  }

  function renderDashboard(){
    const daysSel = parseInt($('#chartDays').value||state.settings.chartDays||14,10);
    state.settings.chartDays = daysSel;
    rebuildGlycoHistory(Math.max(30, daysSel));
    const ds=todayStr();
    const meals=state.meals.filter(m=>m.date===ds);
    const wos=state.workouts.filter(w=>w.date===ds);
    const kcal=meals.reduce((s,m)=> s+num(m.kcal),0);
    const protein=meals.reduce((s,m)=> s+num(m.protein),0);
    const fiber=meals.reduce((s,m)=> s+num(m.fiber),0);
    $('#kcalToday').textContent=Math.round(kcal);
    $('#proteinToday').textContent=Math.round(protein);
    $('#fiberToday').textContent=Math.round(fiber);
    $('#proteinProgress').value=clamp(protein/state.settings.proteinTarget*100,0,100);
    $('#fiberProgress').value=clamp(fiber/state.settings.fiberTarget*100,0,100);

    const gly=state.glycoHistory[ds]||0; $('#glycoNow').textContent=`${Math.round(gly)} g`;
    const pct=clamp(gly/state.settings.glycoCap*100,0,100); const bar=$('#glycoBar'); bar.value=pct;
    const wrap=$('#glycoBarWrap'); wrap.classList.remove('ok','warn','danger'); wrap.classList.add(pct<25?'danger':pct<50?'warn':'ok');
    $('#glycoHint').textContent = pct<25?'Low — consider carbs/rest': pct<50?'Moderate — easy day':'Good — ready to train';

    $('#todayWorkouts').innerHTML = wos.length ? wos.map(renderWorkoutItem).join('') : '<span class="muted">No workouts yet.</span>';
    $('#todayMeals').innerHTML = meals.length ? meals.map(renderMealItem).join('') : '<span class="muted">No meals yet.</span>';

    drawGlycoChart(daysSel);
    $('#chartDaysLabel').textContent = daysSel + 'd';

    $('#streakDays').textContent = computeStreak();
    const weekDates = rangeDays(7).map(d=>d.toISOString().slice(0,10));
    const weekMeals = state.meals.filter(m=>weekDates.includes(m.date));
    const weekProtein = weekMeals.reduce((s,m)=> s+num(m.protein),0);
    const weekWos = state.workouts.filter(w=>weekDates.includes(w.date)).length;
    $('#proteinWeek').textContent = Math.round(weekProtein);
    $('#workoutsWeek').textContent = weekWos;

    const r = latestReadiness();
    $('#readinessScore').textContent = r.score!=null ? Math.round(r.score) : '–';
    $('#readinessLabel').textContent = r.label || '–';

    $('#carbPlan').textContent = Math.round(smartCarbPlan()) + ' g';

    attachEditHandlers();
    save(state);
    maybeAutosave();
  }

  function renderWorkoutItem(w){
    let text = '';
    if(w.type==='strength'){ text = `${w.sets}×${w.reps} @ ${w.weight}kg`; }
    else if(w.type==='cardio'){ text = `${w.mins} min (intensity ${w.intensity})`; }
    const tag = (w.category && w.type==='strength') ? `<span class="tag">${w.category}</span>` : '';
    return `<div class="entry" data-kind="workout" data-id="${w.id}"><strong>${w.name||w.type}</strong> — ${text} ${tag}</div>`;
  }
  function renderMealItem(m){
    return `<div class="entry" data-kind="meal" data-id="${m.id}"><strong>${m.name}</strong> — ${Math.round(num(m.kcal))} kcal â€¢ C${num(m.carbs)} P${num(m.protein)} F${num(m.fat)} Fib${num(m.fiber)}</div>`;
  }

  function renderHistory(){
    const type = $('#histType').value;
    const cat = $('#histCat').value;
    const prot = $('#histProtein').value;
    const groups={};
    for(const m of state.meals){ groups[m.date]=groups[m.date]||{meals:[],workouts:[]}; groups[m.date].meals.push(m); }
    for(const w of state.workouts){ groups[w.date]=groups[w.date]||{meals:[],workouts:[]}; groups[w.date].workouts.push(w); }
    const dates=Object.keys(groups).sort().reverse();
    const el=$('#history');
    if(!dates.length){ el.innerHTML='<span class="muted">Nothing yet.</span>'; return; }
    const rows = [];
    for(const d of dates){
      let ws = groups[d].workouts; let ms = groups[d].meals;
      if(type){ ws = ws.filter(x=>x.type===type); }
      if(cat){ ws = ws.filter(x=> (x.type!=='strength') || (x.category===cat)); }
      if(prot){
        const totalP = ms.reduce((s,m)=>s+num(m.protein),0);
        const hit = totalP >= (state.settings.proteinTarget||140);
        if(prot==='hit' && !hit) { ws=[]; ms=[]; }
        if(prot==='miss' && hit) { ws=[]; ms=[]; }
      }
      if(!ws.length && !ms.length) continue;
      rows.push(`<div class="group"><h4>${d}</h4>${ws.map(renderWorkoutItem).join('')||'<div class="muted">No workouts.</div>'}${ms.map(renderMealItem).join('')||'<div class="muted">No meals.</div>'}</div>`);
    }
    el.innerHTML = rows.join('') || '<span class="muted">No matching days.</span>';
    attachEditHandlers();
  }
  $('#histType').addEventListener('change', renderHistory);
  $('#histCat').addEventListener('change', renderHistory);
  $('#histProtein').addEventListener('change', renderHistory);

  $('#chartDays').addEventListener('change', renderDashboard);
  function drawGlycoChart(days){
    const c=$('#glycoChart'); const tip=$('#glycoTip');
    const ctx=c.getContext('2d');
    const w=c.width=c.clientWidth*devicePixelRatio; const h=c.height=160*devicePixelRatio;
    ctx.clearRect(0,0,w,h);
    const cap=state.settings.glycoCap;
    const labels=[]; const values=[];
    const now=new Date();
    for(let i=days-1;i>=0;i--){
      const d=new Date(now); d.setDate(now.getDate()-i);
      const ds=d.toISOString().slice(0,10);
      labels.push(ds); values.push(state.glycoHistory && state.glycoHistory[ds]!=null ? state.glycoHistory[ds] : cap*0.7);
    }
    const padding=12*devicePixelRatio; const gx0=padding, gx1=w-padding, gy0=padding, gy1=h-padding;
    const x=i=> gx0+(gx1-gx0)*i/(days-1); const y=v=> gy1-(gy1-gy0)*(v/cap);
    ctx.globalAlpha=0.25; ctx.strokeStyle='#3a3f55'; ctx.lineWidth=1*devicePixelRatio;
    for(const frac of [0.25,0.5,0.75,1.0]){ const gy=y(cap*frac); ctx.beginPath(); ctx.moveTo(gx0,gy); ctx.lineTo(gx1,gy); ctx.stroke(); } ctx.globalAlpha=1;
    ctx.beginPath(); for(let i=0;i<values.length;i++){ const xv=x(i), yv=y(values[i]); if(i===0) ctx.moveTo(xv,yv); else ctx.lineTo(xv,yv); } ctx.strokeStyle='#57cc99'; ctx.lineWidth=2.5*devicePixelRatio; ctx.stroke();
    const grad=ctx.createLinearGradient(0,gy0,0,gy1); grad.addColorStop(0,'rgba(87,204,153,0.25)'); grad.addColorStop(1,'rgba(87,204,153,0.02)'); ctx.lineTo(gx1,gy1); ctx.lineTo(gx0,gy1); ctx.closePath(); ctx.fillStyle=grad; ctx.fill();

    function showTip(px,py,txt){ const b=c.getBoundingClientRect(); tip.style.left=(b.left+px/devicePixelRatio+10)+'px'; tip.style.top=(b.top+py/devicePixelRatio-30)+'px'; tip.innerHTML=txt; tip.hidden=false; }
    function hideTip(){ tip.hidden=true; }
    c.onmousemove = c.ontouchstart = (ev)=>{
      const clientX = ev.touches? ev.touches[0].clientX : ev.clientX;
      const rect = c.getBoundingClientRect();
      const px = (clientX - rect.left) * devicePixelRatio;
      const frac = clamp((px - gx0)/(gx1-gx0),0,1);
      const i = Math.round(frac*(days-1));
      const xv = x(i), yv = y(values[i]);
      const ds = labels[i].slice(5);
      showTip(xv, yv, `<strong>${Math.round(values[i])} g</strong><div class="smallmuted">${ds}</div>`);
    };
    c.onmouseleave = hideTip;
  }

  function dateAdd(d,delta){ const x=new Date(d); x.setDate(x.getDate()+delta); return x; }
  function rangeDays(n){ const a=[]; const now=new Date(); for(let i=0;i<n;i++){ const d=new Date(now); d.setDate(now.getDate()-i); a.push(d); } return a; }
  function computeStreak(){ let streak=0; let d=new Date(); while(true){ const ds=d.toISOString().slice(0,10); const has=state.meals.some(x=>x.date===ds)||state.workouts.some(x=>x.date===ds)||state.checks.some(x=>x.date===ds); if(!has) break; streak++; d=dateAdd(d,-1);} return streak; }

  function latestReadiness(){
    if(!(state.checks||[]).length) return {score:null,label:null};
    const last = [...state.checks].sort((a,b)=> a.date<b.date?1:-1)[0];
    const sleep = clamp(num(last.sleep),0,12); const rhr = num(last.rhr)||60; const mood = last.mood||'ok';
    const moodScore = {great:1.0, ok:0.8, tired:0.6, stressed:0.55, sore:0.65}[mood] || 0.8;
    const base = 50 + (sleep-7)*5 - (rhr-60)*0.5;
    const score = clamp(base*moodScore, 0, 100);
    const label = (score>=75)?'Train': (score>=55)?'Easy':'Rest';
    return {score, label};
  }

  function smartCarbPlan(){
    const cfg=state.settings; const tomorrow=new Date(); tomorrow.setDate(tomorrow.getDate()+1);
    const ts = tomorrow.toISOString().slice(0,10);
    const planned = state.workouts.filter(w=>w.date===ts);
    let cost=0;
    for(const w of planned){
      if(w.type==='strength'){ cost += (num(w.sets)||0)*cfg.setCost; }
      else if(w.type==='cardio'){ const mins=num(w.mins)||0; const intensity=clamp(num(w.intensity)||1,1,5); cost += mins*cfg.cardioGpmIntensity1*intensity; }
      else { cost += 10; }
    }
    const desired = cfg.glycoCap*0.75;
    const todayEnd = state.glycoHistory[todayStr()]||cfg.glycoCap*0.7;
    const predictedStart = clamp(todayEnd - cost, 0, cfg.glycoCap);
    const gramsNeeded = clamp(desired - predictedStart, 0, cfg.glycoCap);
    const carbsNeeded = gramsNeeded>0 ? (gramsNeeded*100)/(cfg.uptakePct||85) : 0;
    return carbsNeeded;
  }

  function maybeAutosave(){
    try{
      if(!state.settings.autosave) return;
      const t = todayStr();
      if(state.settings.lastBackup === t) return;
      const blob = new Blob([JSON.stringify(state,null,2)], {type:'application/json'});
      const a=document.createElement('a');
      a.href=URL.createObjectURL(blob);
      a.download = `glycotank-backup-${t}.json`;
      document.body.appendChild(a); a.click(); URL.revokeObjectURL(a.href); a.remove();
      state.settings.lastBackup = t; save(state);
    }catch(e){ /* ignore */ }
  }

  function requestReminderPerms(){ return Promise.resolve(false); } // no-op here

  function renderSettings(){
    $('#sProtein').value=state.settings.proteinTarget;
    $('#sFiber').value=state.settings.fiberTarget;
    $('#sCarb').value=state.settings.carbGuide;
    $('#sGlycoCap').value=state.settings.glycoCap;
    $('#sUptake').value=state.settings.uptakePct;
    $('#sSetCost').value=state.settings.setCost;
    $('#sCardioGpm').value=state.settings.cardioGpmIntensity1;
  }
  $('#saveSettings').addEventListener('click', ()=>{
    state.settings.proteinTarget=num($('#sProtein').value)||defaults.settings.proteinTarget;
    state.settings.fiberTarget=num($('#sFiber').value)||defaults.settings.fiberTarget;
    state.settings.carbGuide=num($('#sCarb').value)||defaults.settings.carbGuide;
    state.settings.glycoCap=num($('#sGlycoCap').value)||defaults.settings.glycoCap;
    state.settings.uptakePct=clamp(num($('#sUptake').value)||defaults.settings.uptakePct,10,100);
    state.settings.setCost=num($('#sSetCost').value)||defaults.settings.setCost;
    state.settings.cardioGpmIntensity1=num($('#sCardioGpm').value)||defaults.settings.cardioGpmIntensity1;
    save(state); renderDashboard(); alert('Settings saved.');
  });
  $('#resetDefaults').addEventListener('click', ()=>{
    state.settings = JSON.parse(JSON.stringify(defaults.settings)); save(state); renderSettings(); renderDashboard();
  });

  function download(filename, text){ const blob=new Blob([text],{type:'text/plain'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=filename; a.click(); URL.revokeObjectURL(url); }
  $('#exportJson').addEventListener('click', ()=>{ download('glycotank-export.json', JSON.stringify(state,null,2)); });
  $('#exportCSV').addEventListener('click', ()=>{
    const wcsv=['id,date,type,name,category,exercise,sets,reps,weight,mins,intensity,notes'];
    for(const w of state.workouts){ wcsv.push([w.id,w.date,w.type,quote(w.name),w.category||'',quote(w.exercise||''),w.sets||'',w.reps||'',w.weight||'',w.mins||'',w.intensity||'',quote(w.notes||'')].join(',')); }
    const mcsv=['id,date,name,kcal,carbs,protein,fat,fiber,notes'];
    for(const m of state.meals){ mcsv.push([m.id,m.date,quote(m.name),m.kcal||'',m.carbs||'',m.protein||'',m.fat||'',m.fiber||'',quote(m.notes||'')].join(',')); }
    download('workouts.csv', wcsv.join('\n')); download('meals.csv', mcsv.join('\n'));
  });
  function quote(s){ if(s==null) return ''; const t=String(s); if(t.includes(',')||t.includes('\"')||t.includes('\n')){ return '\"' + t.replace(/\"/g,'\"\"') + '\"'; } return t; }
  $('#clearAll').addEventListener('click', ()=>{ if(confirm('This will delete all local data. Proceed?')){ localStorage.removeItem('glycotank'); Object.assign(state, JSON.parse(JSON.stringify(defaults))); renderDashboard(); renderHistory(); renderSettings(); alert('Cleared.'); }});

  $('#quickAddWorkout').addEventListener('click', e=>{ e.preventDefault(); $('#nav [data-tab=\"workout\"]').click(); });
  $('#quickAddMeal').addEventListener('click', e=>{ e.preventDefault(); $('#nav [data-tab=\"meal\"]').click(); });

  $('#tab-dash').hidden=false; $('#tab-workout').hidden=true; $('#tab-meal').hidden=true; $('#tab-checkin').hidden=true; $('#tab-history').hidden=true; $('#tab-settings').hidden=true;

  renderDashboard(); renderHistory(); renderSettings();

})();
