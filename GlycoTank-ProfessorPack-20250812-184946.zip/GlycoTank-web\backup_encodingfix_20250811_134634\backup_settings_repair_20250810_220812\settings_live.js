﻿(function(){
  function $(id){ return document.getElementById(id); }
  function num(v){ var n=parseFloat((v??"").toString().trim()); return isNaN(n)?null:n; }

  var IDS = ["sProtein","sFiber","sCarb","sGlycoCap","sUptake","sSetCost","sCardioGpm"];

  function load(){ try { return JSON.parse(localStorage.getItem("glycotank")||"{}"); } catch(e){ return {}; } }
  function save(s){ localStorage.setItem("glycotank", JSON.stringify(s)); }

  function ensure(s){
    s = s||{};
    s.settings = Object.assign({
      proteinTarget:140, fiberTarget:28, carbGuide:250, glycoCap:400,
      uptakePct:85, setCost:6.0, cardioGpmIntensity1:0.33
    }, s.settings||{});
    s.meta = Object.assign({ userSetSettings:false }, s.meta||{});
    return s;
  }

  // Fill inputs from current settings (called on load and when entering Settings)
  function fillInputs(){
    var s = ensure(load()).settings;
    if ($("sProtein"))   $("sProtein").value   = (s.proteinTarget ?? "");
    if ($("sFiber"))     $("sFiber").value     = (s.fiberTarget ?? "");
    if ($("sCarb"))      $("sCarb").value      = (s.carbGuide ?? "");
    if ($("sGlycoCap"))  $("sGlycoCap").value  = (s.glycoCap ?? "");
    if ($("sUptake"))    $("sUptake").value    = (s.uptakePct ?? "");
    if ($("sSetCost"))   $("sSetCost").value   = (s.setCost ?? "");
    if ($("sCardioGpm")) $("sCardioGpm").value = (s.cardioGpmIntensity1 ?? "");
  }

  // Debounced autosave on any change in Settings fields
  var t=null;
  function autosave(){
    if (t) clearTimeout(t);
    t = setTimeout(function(){
      try{
        var store = ensure(load());
        function upd(id, key, clampFn){
          var el=$(id); if(!el) return;
          var v = num(el.value);
          if(v===null) return; // ignore empty
          if (typeof clampFn==="function") v = clampFn(v);
          store.settings[key] = v;
          if (window.state && window.state.settings) window.state.settings[key] = v;
        }

        upd("sProtein",   "proteinTarget");
        upd("sFiber",     "fiberTarget");
        upd("sCarb",      "carbGuide");
        upd("sGlycoCap",  "glycoCap",  function(v){ return Math.max(100, Math.round(v)); });
        upd("sUptake",    "uptakePct", function(v){ return Math.max(10, Math.min(100, Math.round(v))); });
        upd("sSetCost",   "setCost",   function(v){ return Math.max(0, v); });
        upd("sCardioGpm", "cardioGpmIntensity1", function(v){ return Math.max(0, v); });

        store.meta.userSetSettings = true; // stop showing "Using defaults"
        save(store);

        // Refresh UI immediately
        if (typeof window.renderDashboard === "function") { try{ window.renderDashboard(); }catch(e){} }
        if (typeof window.renderSettings  === "function") { try{ window.renderSettings();  }catch(e){} }

        // Remove defaults hint if present
        var dh=document.getElementById("defaultsHint"); if(dh) dh.remove();
      }catch(e){ console.warn("Settings autosave failed", e); }
    }, 150);
  }

  function hook(){
    IDS.forEach(function(id){
      var el=$(id);
      if(!el) return;
      ["input","change","blur"].forEach(function(evt){ el.addEventListener(evt, autosave); });
    });
    // Initial fill (so values appear when landing on Settings)
    fillInputs();
  }

  // Run on load
  if (document.readyState==="loading") { document.addEventListener("DOMContentLoaded", hook); } else { hook(); }

  // Also re-fill when the Settings tab is opened
  var nav=document.getElementById("nav");
  if(nav){
    nav.addEventListener("click", function(e){
      var b = e.target && e.target.closest && e.target.closest("button[data-tab]");
      if(b && b.dataset.tab==="settings"){ setTimeout(fillInputs, 0); }
    });
  }

  // If Personalize updates settings, reflect them here without reload
  window.addEventListener("storage", function(ev){
    if(ev.key==="glycotank"){ fillInputs(); }
  });
})();

