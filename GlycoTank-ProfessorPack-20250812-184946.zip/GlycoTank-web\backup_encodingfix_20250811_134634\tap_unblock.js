﻿(function(){
  function seen(){
    try{ return JSON.parse(localStorage.getItem("glycotank_onboard_seen")||"{}").seen===true; }
    catch(e){ return false; }
  }
  function resetSlides(){
    var slides=document.querySelectorAll(".onSlide");
    slides.forEach(function(el,i){ el.classList.toggle("active", i===0); });
    var back=document.getElementById("onBack"); if(back) back.disabled=true;
    var next=document.getElementById("onNext"); if(next) next.textContent="Next";
    var dots=document.getElementById("onDots");
    if(dots){ dots.innerHTML=""; for(var i=0;i<slides.length;i++){ var d=document.createElement("div"); d.className="dot"+(i===0?" active":""); dots.appendChild(d); } }
  }
  function killOverlays(){
    var s = seen();
    document.querySelectorAll(".onboard-overlay").forEach(function(ov){
      var isHidden = ov.hasAttribute("hidden") || ov.style.display==="none";
      if (s || isHidden) { try{ ov.remove(); }catch(_){} }
      else { // first run → make sure it's visible & interactive
        ov.hidden = false; ov.style.display = ""; ov.style.pointerEvents="auto";
      }
    });
    document.body.style.overflow="";
    ["body","main","header","footer","#tab-dash","#tab-workout","#tab-meal","#tab-checkin","#tab-history","#tab-settings","#tab-personalize"]
      .forEach(function(sel){ var el=document.querySelector(sel); if(el){ el.style.pointerEvents="auto"; }});
  }
  // Public open/close
  window.GT_inlineOpen = function(){
    try{ localStorage.removeItem("glycotank_onboard_seen"); }catch(e){}
    var ov=document.getElementById("onboardOverlay");
    if(ov){
      ov.hidden=false; ov.style.display=""; ov.style.pointerEvents="auto";
      document.body.style.overflow="hidden";
      resetSlides();
    }
  };
  var oldClose = window.GT_inlineClose;
  window.GT_inlineClose = function(){
    try{ if(oldClose) oldClose(); }catch(_){}
    var ov=document.getElementById("onboardOverlay");
    if(ov){
      try{ localStorage.setItem("glycotank_onboard_seen", JSON.stringify({seen:true,ts:Date.now()})); }catch(e){}
      document.body.style.overflow="";
      ov.hidden=true; ov.style.display="none"; ov.style.pointerEvents="none";
      try{ ov.parentNode.removeChild(ov); }catch(e){}
    }
    killOverlays();
  };

  function maybeFirstRun(){ if(!seen()){ window.GT_inlineOpen(); } }

  // Wire footer/settings links to open
  document.addEventListener("click", function(e){
    var t = e.target && e.target.closest && e.target.closest("#showIntroBtn, #showIntroLink");
    if(!t) return; e.preventDefault(); window.GT_inlineOpen();
  });

  if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded", function(){ killOverlays(); setTimeout(maybeFirstRun,0); });
  } else { killOverlays(); setTimeout(maybeFirstRun,0); }
})();

