﻿(function(){
  function closeIntro(){
    var ov = document.getElementById("onboardOverlay");
    if(!ov) return;
    ov.hidden = true;
    document.body.style.overflow = "";
    try { localStorage.setItem("glycotank_onboard_seen", JSON.stringify({seen:true, ts:Date.now()})); } catch(e){}
  }

  // Click handlers: X always closes; Next closes when it says "Let's go"
  document.addEventListener("click", function(e){
    var btn = e.target && e.target.closest && e.target.closest("#onClose, #onNext");
    if(!btn) return;
    if(btn.id === "onClose"){ e.preventDefault(); closeIntro(); return; }
    if(btn.id === "onNext"){
      var txt = (btn.textContent || "").toLowerCase();
      if (txt.includes("let")) { e.preventDefault(); closeIntro(); }
    }
  });

  // Esc closes too
  document.addEventListener("keydown", function(e){
    if(e.key === "Escape") closeIntro();
  });
})();

