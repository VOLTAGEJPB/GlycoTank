﻿(function(){
  function $(id){ return document.getElementById(id); }
  function num(v){ var n=parseFloat((v??"").toString().trim()); return isNaN(n)?null:n; }

  var IDS = ["sProtein","sFiber","sCarb","sGlycoCap","sUptake","sSetCost","sCardioGpm"];

  function load(){ try { return JSON.parse(localStorage.getItem("glycotank")||"{}"); } catch(e){ return {}; } }
  function save(s){ localStorage.setItem("glycotank", JSON.stringify(s)); }
  function ensure(s){
    s=s||{};
    s.settings = Object.assign({
      proteinTarget:140,fiberTarget:28,carbGuide:250,glycoCap:400,
      uptakePct:85,setCost:6.0,cardioGpmIntensity1:0.33
    }, s.settings||{});
    s.meta = Object.assign({ userSetSettings:false }, s.meta||{});
    return s;
  }

  function fillInputs(){
    var st = ensure(load()).settings;
    $("sProtein")  && ($("sProtein").value  = st.proteinTarget ?? "");
    $("sFiber")    && ($("sFiber").value    = st.fiberTarget ?? "");
    $("sCarb")     && ($("sCarb").value     = st.carbGuide ?? "");
    $("sGlycoCap") && ($("sGlycoCap").value = st.glycoCap ?? "");
    $("sUptake")   && ($("sUptake").value   = st.uptakePct ?? "");
    $("sSetCost")  && ($("sSetCost").value  = st.setCost ?? "");
    $("sCardioGpm")&& ($("sCardioGpm").value= st.cardioGpmIntensity1 ?? "");
  }

  var t=null;
  function autosave(){
    if(t) clearTimeout(t);
    t = setTimeout(function(){
      var store = ensure(load());
      function upd(id,key,clamp){ var el=$(id); if(!el) return;
        var v = num(el.value); if(v===null) return;
        if(typeof clamp==="function") v = clamp(v);
        store.settings[key]=v;
        if(window.state && window.state.settings){ window.state.settings[key]=v; }
      }
      upd("sProtein","proteinTarget");
      upd("sFiber","fiberTarget");
      upd("sCarb","carbGuide");
      upd("sGlycoCap","glycoCap",v=>Math.max(100,Math.round(v)));
      upd("sUptake","uptakePct",v=>Math.max(10,Math.min(100,Math.round(v))));
      upd("sSetCost","setCost",v=>Math.max(0,v));
      upd("sCardioGpm","cardioGpmIntensity1",v=>Math.max(0,v));

      store.meta.userSetSettings = true;
      save(store);

      try{ window.renderDashboard && window.renderDashboard(); }catch(_){}
      try{ window.renderSettings && window.renderSettings(); }catch(_){}
      var dh=document.getElementById("defaultsHint"); if(dh) dh.remove();
    },150);
  }

  function hook(){
    IDS.forEach(function(id){ var el=$(id); if(el){ ["input","change","blur"].forEach(e=>el.addEventListener(e,autosave)); } });
    fillInputs();
  }

  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", hook); } else { hook(); }

  var nav=document.getElementById("nav");
  if(nav){
    nav.addEventListener("click", function(e){
      var b = e.target && e.target.closest && e.target.closest("button[data-tab]");
      if(b && b.dataset.tab==="settings"){ setTimeout(fillInputs,0); }
    });
  }

  window.addEventListener("storage", function(ev){ if(ev.key==="glycotank"){ fillInputs(); } });
})();

