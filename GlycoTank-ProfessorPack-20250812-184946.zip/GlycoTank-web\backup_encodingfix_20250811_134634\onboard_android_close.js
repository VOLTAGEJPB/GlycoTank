﻿(function(){
  function hardClose(){
    var ov = document.getElementById("onboardOverlay");
    if(!ov) return;
    ov.hidden = true;
    ov.style.display = "none";               // <-- critical for Android WebView
    ov.setAttribute("aria-hidden","true");
    document.body.style.overflow = "";
    try{ localStorage.setItem("glycotank_onboard_seen", JSON.stringify({seen:true,ts:Date.now()})); }catch(e){}
  }
  // Override any existing close function
  window.GT_inlineClose = hardClose;

  // Also close when Next says "Let's go" (tap-safe)
  function bindFinalNext(){
    var next = document.getElementById("onNext");
    if(!next) return;
    function maybe(e){
      var t = (next.textContent || "").toLowerCase();
      if (t.indexOf("let") > -1) { e.preventDefault(); e.stopPropagation(); hardClose(); }
    }
    ["click","touchend","pointerup"].forEach(function(ev){ next.addEventListener(ev, maybe, {passive:false}); });
  }

  function bindX(){
    var x = document.getElementById("onClose");
    if(!x) return;
    function go(e){ e.preventDefault(); e.stopPropagation(); hardClose(); }
    ["click","touchend","pointerup"].forEach(function(ev){ x.addEventListener(ev, go, {passive:false}); });
  }

  if (document.readyState==="loading") { document.addEventListener("DOMContentLoaded", function(){ bindFinalNext(); bindX(); }); }
  else { bindFinalNext(); bindX(); }
})();

