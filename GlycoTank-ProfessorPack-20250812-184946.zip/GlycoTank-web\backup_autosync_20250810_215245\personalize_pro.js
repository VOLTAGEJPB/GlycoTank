﻿(function(){
  function sel(id){ return document.getElementById(id); }
  function valNum(id){ var v=(sel(id)?.value||"").trim(); var n=parseFloat(v); return isNaN(n)?0:n; }
  function kgFrom(x,units){ var n=parseFloat(x||"0")||0; return (units==="lb")? n*0.453592 : n; }
  function cmFrom(heightCm, ft, inch, mode){
    if(mode==="ftin"){ var f=parseFloat(ft||"0")||0, i=parseFloat(inch||"0")||0; return (f*12+i)*2.54; }
    return parseFloat(heightCm||"0")||0;
  }

  // Mifflin-St Jeor BMR (kcal/day)
  function bmrMSJ(kg, cm, age, sex){
    if(!kg||!cm){ return 0; }
    var base = 10*kg + 6.25*cm - 5*(age||30);
    return Math.round(sex==="f" ? base - 161 : base + 5);
  }

  // Exercise calories via METs (Compendium). kcal/min = MET * 3.5 * kg / 200
  function kcalFromMETs(kg, met, mins){ return (met*3.5*kg/200) * (mins||0); }
  function strengthMinsPerSession(avgSets){ return (avgSets||0) * 2; } // ~2 min per hard set (work + changeover)

  function explain(txt){ var el=sel("pzExplain"); if(el) el.textContent = txt; }

  function calc(){
    var units = sel("pzUnits")?.value || "kg";
    var kg    = kgFrom(sel("pzWeight")?.value, units);
    var sex   = sel("pzSex")?.value || "m";
    var age   = valNum("pzAge")||30;

    var htMode = sel("pzHtUnits")?.value || "cm";
    var cm     = cmFrom(sel("pzHeightCm")?.value, sel("pzHeightFt")?.value, sel("pzHeightIn")?.value, htMode);

    var goal   = sel("pzGoal")?.value || "maintain";
    var lbPerWk = (function(){ var x = parseFloat((sel("pzWeeklyLb")?.value||"0").trim()); if(isNaN(x)) x=0; return Math.max(-2, Math.min(2, x)); })();

    var days   = valNum("pzDays")||3;
    var avgSets= valNum("pzAvgSets")||12;
    var cardio = valNum("pzCardio")||0;
    var inten  = valNum("pzInt")||3;
    var lowCarb= !!(sel("pzLowCarb")?.checked);

    // Baseline energy: BMR * 1.2 (sedentary) + average daily exercise kcal
    var bmr = bmrMSJ(kg, cm, age, sex);
    var base = bmr * 1.20;

    // Strength METs: general ~3.5; vigorous ~6.0 (Compendium). We'll map avgSets heuristic to "general".
    var wkStrengthMin = strengthMinsPerSession(avgSets) * days;
    var kcalStrengthWk = kcalFromMETs(kg, 3.5, wkStrengthMin);

    // Cardio METs mapping by 1..5 → ~3,5,7,9,11 (walk→jog/run spectrum)
    var cardioMET = [0,3,5,7,9,11][inten] || 5;
    var kcalCardioWk = kcalFromMETs(kg, cardioMET, cardio);

    var exDaily = (kcalStrengthWk + kcalCardioWk) / 7;
    var tdee = Math.round(base + exDaily);

    // Weekly change target (lb/wk) → daily kcal adj (3500 kcal/lb rule of thumb)
    var adj = Math.round((lbPerWk * 3500) / 7); // negative lbPerWk gives negative/deficit
    var kcalTarget = Math.max(1200, tdee + adj); // floor for safety

    // Protein (g/kg): evidence-based ranges (ISSN). Higher on cuts.
    var pPerKg = (goal==="cut")
                  ? (Math.abs(lbPerWk) >= 0.75 ? 2.2 : 2.0)
                  : (goal==="gain" ? 1.8 : 2.0);
    var pG = Math.round(kg * pPerKg);

    // Fat (g/kg): pragmatic targets by goal
    var fPerKg = (goal==="cut") ? 0.6 : (goal==="gain" ? 1.0 : 0.8);
    var fG = Math.round(kg * fPerKg);

    // Carbs = remaining calories after P & F
    var kcalPF = 4*pG + 9*fG;
    var cG = Math.max(0, Math.round((kcalTarget - kcalPF) / 4));

    // Glyco parameters
    var cap = Math.round(Math.max(300, Math.min(600, 350 + (kg-70)*1.8 + days*12 + (cardio/4))));
    var uptake = (goal==="gain") ? 90 : ((goal==="cut"||lowCarb) ? 80 : 85);
    var setCost = Math.max(4.5, Math.min(7.5, 5.5 + (kg>90?0.7:(kg<65?-0.5:0))));
    var gpm1 = (kg<65)?0.25 : (kg>90?0.36:0.33);

    // Output
    function put(id, v){ var el=sel(id); if(el) el.textContent = v; }
    put("pzKcalOut", kcalTarget + " kcal");
    put("pzProtOut", pG + " g");
    put("pzFibOut",  Math.round(Math.max(20, Math.min(45, 14 * (kcalTarget/1000)))) + " g"); // 14g / 1000 kcal
    put("pzCarbOut", cG + " g");
    put("pzCapOut",  cap + " g");
    put("pzUptakeOut", uptake + " %");
    put("pzSetCostOut", setCost.toFixed(1) + " g");
    put("pzGpmOut", gpm1.toFixed(2));

    var htTxt = (htMode==="ftin")
      ? ((sel("pzHeightFt")?.value||"—") + "′" + (sel("pzHeightIn")?.value||"—") + "″")
      : ((sel("pzHeightCm")?.value||"—") + " cm");
    explain("MSJ BMR, activity + exercise calories; goal = "+goal+", "+lbPerWk+" lb/wk. Height: "+htTxt+".");

    return {
      kcalTarget:kcalTarget,
      proteinTarget:pG,
      fiberTarget:Math.round(Math.max(20, Math.min(45, 14 * (kcalTarget/1000)))),
      carbGuide:cG,
      glycoCap:cap,
      uptakePct:uptake,
      setCost:setCost,
      cardioGpmIntensity1:gpm1
    };
  }

  function applyToSettings(){
    var rec = calc();
    try {
      var s = (function(){ try { return JSON.parse(localStorage.getItem("glycotank")||"{}"); } catch(e){ return {}; } })();
      s.settings = Object.assign({
        proteinTarget:140, fiberTarget:28, carbGuide:250, glycoCap:400,
        uptakePct:85, setCost:6.0, cardioGpmIntensity1:0.33
      }, s.settings||{});
      s.meta = Object.assign({ userSetSettings:false }, s.meta||{});
      Object.assign(s.settings, rec);
      s.meta.userSetSettings = true;
      localStorage.setItem("glycotank", JSON.stringify(s));
      alert("Applied to Settings.");
      setTimeout(function(){ location.reload(); }, 120);
    } catch(e){
      console.error(e); alert("Could not save settings.");
    }
  }

  function toggleHt(){
    var mode = sel("pzHtUnits")?.value || "cm";
    var cmWrap = sel("pzHtCmWrap"), fiWrap = sel("pzFtInWrap");
    if(cmWrap && fiWrap){
      cmWrap.hidden = (mode!=="cm");
      fiWrap.hidden = (mode!=="ftin");
    }
  }

  function hook(){
    ["pzUnits","pzWeight","pzAge","pzSex","pzHtUnits","pzHeightCm","pzHeightFt","pzHeightIn","pzGoal","pzWeeklyLb","pzDays","pzAvgSets","pzCardio","pzInt","pzLowCarb"]
      .forEach(function(id){
        var el = sel(id); if(el){ ["input","change"].forEach(function(evt){ el.addEventListener(evt, function(){ if(id==="pzHtUnits") toggleHt(); calc(); }); }); }
      });
    var btn = sel("pzApply"); if(btn){ btn.addEventListener("click", applyToSettings); }
    toggleHt(); calc();
  }

  // Init when tab is opened and on load
  if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded", hook);
  } else { hook(); }

  var nav = document.getElementById("nav");
  if(nav){
    nav.addEventListener("click", function(e){
      var b = e.target && e.target.closest && e.target.closest("button[data-tab]");
      if(b && b.dataset.tab==="personalize"){ setTimeout(function(){ toggleHt(); calc(); }, 0); }
    });
  }
})();

