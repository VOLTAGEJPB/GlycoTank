﻿/* disabled: we now show real values in Settings immediately */

