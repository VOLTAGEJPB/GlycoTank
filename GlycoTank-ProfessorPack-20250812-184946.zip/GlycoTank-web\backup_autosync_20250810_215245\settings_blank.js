﻿(function(){
  function blank(){
    ["sProtein","sFiber","sCarb","sGlycoCap","sUptake","sSetCost","sCardioGpm"]
      .forEach(function(id){ var el=document.getElementById(id); if(el) el.value=""; });
  }
  function hook(){
    var nav=document.getElementById("nav");
    if(nav){
      nav.addEventListener("click", function(e){
        var btn = e.target && e.target.closest && e.target.closest("button[data-tab]");
        if(btn && btn.dataset.tab==="settings"){ setTimeout(blank,0); }
      });
    }
    blank(); // also blank on initial load
  }
  if(document.readyState==="loading"){ document.addEventListener("DOMContentLoaded", hook); } else { hook(); }
})();

