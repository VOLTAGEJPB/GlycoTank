﻿(function(){
  function bySel(s){ return document.querySelector(s); }
  function setHTML(el, html){ if(el){ el.innerHTML = html; } }

  // Slide 1: What is Glyco? (plain ASCII to avoid encoding issues)
  setHTML(
    document.querySelector('.onSlide[data-i="0"] .onBody') ||
    document.querySelector('.onSlide.active .onBody'),
    [
      '<p><span class="pill">What is "Glyco"?</span> It is your estimated glycogen fuel tank in grams.</p>',
      '<ul class="onList">',
      '<li>Meals add: carbs x uptake% (e.g., 80 g x 85% = +68 g)</li>',
      '<li>Workouts subtract: hard sets x set cost; cardio mins x g/min x intensity</li>',
      '<li>Day to day: low Glyco = tired, cravings, easier to feel flat; high Glyco = better training pop and focus</li>',
      '</ul>',
      '<p class="smallnote">Tip: Use higher Glyco days for harder sessions; on low days, go easier or plan more carbs.</p>'
    ].join('')
  );

  // Slide 2: Everyday life impact (more practical examples)
  setHTML(
    document.querySelector('.onSlide[data-i="1"] .onBody'),
    [
      '<p><span class="pill">Glyco in everyday life</span></p>',
      '<ul class="onList">',
      '<li>Morning training? A small carb top-up helps raise Glyco so the session feels smoother.</li>',
      '<li>Big leg day later? Aim to enter the day at medium-high Glyco, then refuel after.</li>',
      '<li>Desk day or rest? Lower carbs are fine; keep protein and fiber steady.</li>',
      '<li>Feeling flat or brain-foggy? You might be low on Glyco — either refuel or train easy.</li>',
      '</ul>',
      '<p class="smallnote">Your tank changes with what you eat and how you train. Tracking it removes guesswork.</p>'
    ].join('')
  );

  // Slide 3: Why track it (how it helps)
  setHTML(
    document.querySelector('.onSlide[data-i="2"] .onBody'),
    [
      '<p><span class="pill">Why track Glyco?</span></p>',
      '<ul class="onList">',
      '<li>Choose the right session difficulty for today.</li>',
      '<li>Time your carbs around workouts instead of guessing.</li>',
      '<li>Reduce bonks in cardio and stalls in strength work.</li>',
      '<li>Keep protein and fiber consistent while you adjust carbs.</li>',
      '</ul>',
      '<p class="smallnote" id="onNums">Defaults: Set cost ~6 g  |  Cardio ~0.33 g/min  |  Uptake ~85%  |  Glyco cap ~400 g (tune in Settings)</p>'
    ].join('')
  );

  // If dots/back/next exist, make sure the first slide is active when opened
  // (the existing open logic usually handles this, but this is a gentle nudge)
  var ov = document.getElementById('onboardOverlay');
  if (ov && !ov.hidden) {
    var slides = Array.from(document.querySelectorAll('.onSlide'));
    slides.forEach(function(s, i){ s.classList.toggle('active', i===0); });
    var back = document.getElementById('onBack'); if (back) back.disabled = true;
    var next = document.getElementById('onNext'); if (next) next.textContent = 'Next';
    var dots = document.getElementById('onDots');
    if (dots) {
      dots.innerHTML = '';
      slides.forEach(function(_, i){
        var d = document.createElement('div');
        d.className = 'dot' + (i===0 ? ' active' : '');
        dots.appendChild(d);
      });
    }
  }
})();

